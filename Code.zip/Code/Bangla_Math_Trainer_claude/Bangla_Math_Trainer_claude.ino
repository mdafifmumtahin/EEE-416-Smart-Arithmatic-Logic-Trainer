/**********************************************************************
 *  বাংলা গণিত শেখার যন্ত্র  —  Bangla Math Trainer  v2.0
 *  ESP32 + SSD1306 0.96" OLED + 4x4 Keypad + DFPlayer Mini + WiFiManager
 *
 *  MODES      : গণিত (Arithmetic)  |  লজিক (1-bit Logic)
 *  PHASES     : শিখি (Learning, no timer)  |  যাচাই (Testing, timed)
 *  DIFFICULTY : সহজ / মাঝারি / কঠিন
 *  DASHBOARD  : http://<device-ip>/   (teacher view, Bangla, live + graphs)
 *
 *  KEYPAD MAP
 *    In menus : 2 or A = up, 8 or B = down, # or D = OK, * or C = back
 *    In quiz  : 0-9 = digits, * = clear, # = submit, D = skip/quit
 *
 *  OLED FONT NOTE
 *    u8g2_font_unifont_t_bengali has NO conjunct (যুক্তবর্ণ) shaping.
 *    Every Bangla string in this file is deliberately conjunct-free.
 *    See BN_SAFE_WORDS note at the bottom before adding new text.
 **********************************************************************/

#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <Keypad.h>
#include <Preferences.h>
#include "DFRobotDFPlayerMini.h"
#include <U8g2lib.h>
#include <WiFiManager.h>

// ───────────────────────── HARDWARE ─────────────────────────
#define GREEN_LED   18
#define RED_LED     19
#define BUZZER      23
#define DF_RX_PIN   16      // ESP32 RX2  <- DFPlayer TX
#define DF_TX_PIN   17      // ESP32 TX2  -> DFPlayer RX (put 1k resistor here)
#define SEED_PIN    34

WebServer server(80);
HardwareSerial dfSerial(2);
DFRobotDFPlayerMini myDFPlayer;
Preferences prefs;

U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

const byte ROWS = 4, COLS = 4;
char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};
byte rowPins[ROWS] = {13, 12, 14, 27};
byte colPins[COLS] = {26, 25, 33, 32};
Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

// ───────────────────────── AUDIO TRACK MAP ─────────────────────────
//  0001-0099 : সংখ্যা ১ – ৯৯
//  0100      : শূন্য
#define A_ZERO     128   // শূন্য  (0100 is already "একশ")
#define A_PLUS     101   // যোগ
#define A_MINUS    102   // বিয়োগ
#define A_TIMES    103   // গুণ
#define A_DIV      104   // ভাগ
#define A_EQUALS   105   // সমান কত?
#define A_RIGHT    106   // সঠিক হয়েছে
#define A_WRONG    107   // হয়নি
#define A_DONE     108   // শেষ
#define A_EASY     109   // সহজ
#define A_MEDIUM   110   // মাঝারি
#define A_HARD     111   // কঠিন
#define A_LEARN    112   // চলো শিখি
#define A_TEST     113   // চলো যাচাই করি
#define A_MATH     114   // গণিত
#define A_LOGIC    115   // লজিক
#define A_AND      116
#define A_OR       117
#define A_NOT      118
#define A_XOR      119
#define A_XNOR     120
#define A_NAND     121
#define A_NOR      122
#define A_TIMEUP   123   // সময় শেষ
#define A_WELCOME  124   // স্বাগতম
#define A_GREAT    125   // দারুণ হয়েছে
#define A_TRYAGAIN 126   // আবার চেষ্টা করো
#define A_ANSWERIS 127   // উত্তর হলো

bool dfOK = false;

// ───────────────────────── DATA MODEL ─────────────────────────
#define MAX_STUDENTS  5
#define HIST_LEN      12
#define QUIZ_LEN      5

// topic index
enum { T_ADD = 0, T_SUB, T_MUL, T_DIV, T_LOGIC, T_COUNT };

struct Student {
  char     name[24];
  uint16_t tTot, tCor;              // lifetime testing totals
  uint16_t topTot[T_COUNT];
  uint16_t topCor[T_COUNT];
  uint8_t  histN;                   // how many sessions stored
  uint8_t  hist[HIST_LEN];          // % score per finished test session
  uint8_t  bestPct;
};
Student students[MAX_STUDENTS];
int8_t curStudent = 0;

// live state mirrored to the dashboard
struct Live {
  bool     active   = false;
  int8_t   student  = -1;
  uint8_t  mode     = 0;   // 0 math, 1 logic
  uint8_t  phase    = 0;   // 0 learn, 1 test
  uint8_t  diff     = 0;   // 0 easy, 1 med, 2 hard
  String   q        = "";
  String   typed    = "";
  uint8_t  qIdx     = 0;
  uint8_t  qTotal   = 0;
  uint8_t  cor      = 0;
  uint8_t  wrg      = 0;
  int16_t  secLeft  = -1;
  uint8_t  lastRes  = 0;   // 0 none, 1 right, 2 wrong, 3 timeout
} live;

// শিক্ষক ড্যাশবোর্ড থেকে যা পাঠাতে পারেন
struct Remote {
  volatile bool start = false;      // "যন্ত্রে শুরু করুন" চাপা হয়েছে
  int8_t  student = 0;
  uint8_t mode = 0, phase = 0, diff = 0;
} remote;

// ───────────────────────── SMALL UTILITIES ─────────────────────────
String toBanglaNum(const String &en) {
  String bn = "";
  for (uint16_t i = 0; i < en.length(); i++) {
    switch (en[i]) {
      case '0': bn += "০"; break;  case '1': bn += "১"; break;
      case '2': bn += "২"; break;  case '3': bn += "৩"; break;
      case '4': bn += "৪"; break;  case '5': bn += "৫"; break;
      case '6': bn += "৬"; break;  case '7': bn += "৭"; break;
      case '8': bn += "৮"; break;  case '9': bn += "৯"; break;
      default : bn += en[i];
    }
  }
  return bn;
}

/*  ── কার (kar) ঠিক করার ফাংশন ───────────────────────────────────────
    ইউনিকোডে ি ে ৈ ো ৌ ব্যঞ্জনের *পরে* জমা থাকে, কিন্তু দেখতে হয় *আগে*।
    u8g2-তে কোনো shaping engine নেই, তাই সে যেভাবে জমা আছে সেভাবেই আঁকে —
    ফলে "কি" দেখায় "কি" নয়, "ক"+"ি" উল্টো হয়ে। এই ফাংশন কোডপয়েন্টগুলো
    হাতে সাজিয়ে দেয়। ো = ে + া এবং ৌ = ে + ৗ ভেঙে দুই পাশে বসায়।

    যদি তোমার u8g2/ফন্ট ভার্সন নিজেই ঠিকভাবে সাজায় (স্ক্রিনে টেস্ট করে
    দেখো), তাহলে নিচের 1 কে 0 করে দিলেই এই ফাংশন বন্ধ হয়ে যাবে।        */
#define BN_REORDER_KAR 1

String bnFix(const String &in) {
#if !BN_REORDER_KAR
  return in;
#else
  String out = "";
  int lastStart = -1;               // শেষ যে কোডপয়েন্ট বসানো হয়েছে
  int i = 0, n = in.length();

  while (i < n) {
    uint8_t c = (uint8_t)in[i];
    int len = (c < 0x80) ? 1 : ((c & 0xE0) == 0xC0) ? 2 : ((c & 0xF0) == 0xE0) ? 3 : 4;
    if (i + len > n) len = 1;

    if (len == 3 && lastStart >= 0 && (uint8_t)in[i] == 0xE0) {
      uint8_t b1 = (uint8_t)in[i + 1], b2 = (uint8_t)in[i + 2];
      bool isI  = (b1 == 0xA6 && b2 == 0xBF);   // ি
      bool isE  = (b1 == 0xA7 && b2 == 0x87);   // ে
      bool isAI = (b1 == 0xA7 && b2 == 0x88);   // ৈ
      bool isO  = (b1 == 0xA7 && b2 == 0x8B);   // ো
      bool isAU = (b1 == 0xA7 && b2 == 0x8C);   // ৌ

      if (isI || isE || isAI || isO || isAU) {
        String pre  = isI ? "\u09BF" : (isAI ? "\u09C8" : "\u09C7");
        String post = isO ? "\u09BE" : (isAU ? "\u09D7" : "");
        String head = out.substring(0, lastStart);
        String base = out.substring(lastStart);
        out = head;  out += pre;  out += base;  out += post;
        lastStart = head.length() + pre.length();
        i += len;
        continue;
      }
    }

    lastStart = out.length();
    for (int k = 0; k < len; k++) out += in[i + k];
    i += len;
  }
  return out;
#endif
}

bool isAsciiStr(const char *s) {
  while (*s) { if ((uint8_t)*s > 127) return false; s++; }
  return true;
}
void setFontFor(const char *s) {
  u8g2.setFont(isAsciiStr(s) ? u8g2_font_7x14B_tr : u8g2_font_unifont_t_bengali);
}

// keeps the web dashboard alive while the device waits
void serviceDelay(uint32_t ms) {
  uint32_t t0 = millis();
  while (millis() - t0 < ms) { server.handleClient(); delay(2); }
}
char getKeyLive() { server.handleClient(); return keypad.getKey(); }

void beep(uint16_t ms) { digitalWrite(BUZZER, HIGH); delay(ms); digitalWrite(BUZZER, LOW); }

// ───────────────────────── AUDIO ─────────────────────────
void audioPlay(int track) { if (dfOK) myDFPlayer.play(track); }
void audioSay(int track, uint32_t waitMs) { audioPlay(track); serviceDelay(waitMs); }

// speaks 0-99 as one track; larger numbers are skipped (no track exists)
void sayNumber(long n) {
  if (n == 0)            audioSay(A_ZERO, 900);
  else if (n > 0 && n < 100) audioSay((int)n, 900);
}

/*  Fixes the "no sound until I press reset" problem.
    Root cause: DFPlayer's own MCU needs ~1-1.5 s after power-up before it
    answers on UART. On a cold boot the ESP32 is ready far sooner, so
    begin() times out; on a reset the module is already awake, so it works.
    Fix = settle delay + hardware reset + retries + volume set twice.      */
void initAudio() {
  dfSerial.begin(9600, SERIAL_8N1, DF_RX_PIN, DF_TX_PIN);
  delay(1200);                                  // let the module boot

  for (uint8_t attempt = 0; attempt < 4 && !dfOK; attempt++) {
    if (myDFPlayer.begin(dfSerial, /*isACK=*/true, /*doReset=*/true)) dfOK = true;
    else delay(600);
  }

  if (dfOK) {
    myDFPlayer.reset();      delay(900);        // clean state, card re-mounted
    myDFPlayer.outputDevice(DFPLAYER_DEVICE_SD); delay(150);
    myDFPlayer.volume(24);   delay(60);
    myDFPlayer.volume(24);                      // second write: first is often eaten
  }
}

// ───────────────────────── OLED HELPERS ─────────────────────────
void drawCenter(const String &raw, int y) {
  String s = bnFix(raw);
  setFontFor(s.c_str());
  int w = u8g2.getUTF8Width(s.c_str());
  u8g2.setCursor((128 - w) / 2, y);
  u8g2.print(s);
}

void screenMsg(const String &l1, const String &l2 = "", const String &l3 = "") {
  u8g2.clearBuffer();
  if (l2 == "" && l3 == "") drawCenter(l1, 38);
  else if (l3 == "")      { drawCenter(l1, 27); drawCenter(l2, 50); }
  else                    { drawCenter(l1, 20); drawCenter(l2, 40); drawCenter(l3, 60); }
  u8g2.sendBuffer();
}

void drawTimerBar(int16_t secLeft, int16_t secTotal) {
  if (secLeft < 0 || secTotal <= 0) return;
  int w = map(secLeft, 0, secTotal, 0, 126);
  if (w < 0) w = 0;
  u8g2.drawFrame(0, 0, 128, 6);
  u8g2.drawBox(1, 1, w, 4);
}

// question screen: timer bar, question, typed answer, progress
void screenQuestion(const String &qText, const String &typed,
                    uint8_t res, int16_t secLeft, int16_t secTotal,
                    uint8_t qIdx, uint8_t qTotal) {
  u8g2.clearBuffer();
  drawTimerBar(secLeft, secTotal);

  drawCenter(qText, 32);

  String line = "উঃ ";
  line += typed;
  if (res == 1) line += " ✔";
  else if (res == 2) line += " ✖";
  drawCenter(line, 54);

  u8g2.setFont(u8g2_font_4x6_tr);
  char buf[12];
  snprintf(buf, sizeof(buf), "%u/%u", qIdx, qTotal);
  u8g2.setCursor(128 - u8g2.getStrWidth(buf) - 1, 63);
  u8g2.print(buf);

  u8g2.sendBuffer();
}

/*  Scrolling menu for the tiny 0.96" panel.
    Shows a title, 2 items per page, and a "পাতা ১/৩" footer.
    Returns the chosen index, or -1 if the user backed out.              */
int menuSelect(const String &title, const char *const items[], uint8_t n,
               uint8_t startIdx = 0) {
  int sel = startIdx;
  const uint8_t PER = 2;
  uint8_t pages = (n + PER - 1) / PER;
  bool redraw = true;

  while (true) {
    if (redraw) {
      uint8_t top = (sel / PER) * PER;
      u8g2.clearBuffer();

      drawCenter(title, 12);
      u8g2.drawHLine(0, 15, 128);

      for (uint8_t i = 0; i < PER; i++) {
        uint8_t idx = top + i;
        if (idx >= n) break;
        int y = 34 + i * 17;
        String row = bnFix(String(items[idx]));
        setFontFor(row.c_str());
        int w = u8g2.getUTF8Width(row.c_str());
        int x = (128 - w) / 2;
        if (idx == sel) {
          u8g2.drawRBox(x - 7, y - 13, w + 14, 16, 3);
          u8g2.setDrawColor(0);
        }
        u8g2.setCursor(x, y);
        u8g2.print(row);
        u8g2.setDrawColor(1);
      }

      String foot = String("পাতা ");
      foot += toBanglaNum(String(sel / PER + 1));
      foot += "/";
      foot += toBanglaNum(String(pages));
      foot = bnFix(foot);
      u8g2.setFont(u8g2_font_unifont_t_bengali);
      int fw = u8g2.getUTF8Width(foot.c_str());
      u8g2.setCursor((128 - fw) / 2, 63);
      u8g2.print(foot);

      u8g2.sendBuffer();
      redraw = false;
    }

    if (remote.start) { return -2; }          // শিক্ষক ড্যাশবোর্ড থেকে শুরু করেছেন

    char k = getKeyLive();
    if (!k) { delay(5); continue; }

    if (k == '2' || k == 'A') { sel = (sel - 1 + n) % n; redraw = true; beep(15); }
    else if (k == '8' || k == 'B') { sel = (sel + 1) % n; redraw = true; beep(15); }
    else if (k == '#' || k == 'D') { beep(40); return sel; }
    else if (k == '*' || k == 'C') { beep(40); return -1; }
  }
}

// ───────────────────────── PERSISTENCE ─────────────────────────
void resetStudent(uint8_t i, bool keepName = true) {
  if (!keepName) snprintf(students[i].name, sizeof(students[i].name), "শিশু %d", i + 1);
  students[i].tTot = students[i].tCor = 0;
  for (uint8_t t = 0; t < T_COUNT; t++) { students[i].topTot[t] = 0; students[i].topCor[t] = 0; }
  students[i].histN = 0;
  memset(students[i].hist, 0, sizeof(students[i].hist));
  students[i].bestPct = 0;
}

void saveAll() {
  prefs.begin("btrainer", false);
  prefs.putBytes("st", students, sizeof(students));
  prefs.end();
}

void loadAll() {
  prefs.begin("btrainer", true);
  size_t len = prefs.getBytesLength("st");
  bool ok = (len == sizeof(students));
  if (ok) prefs.getBytes("st", students, sizeof(students));
  prefs.end();
  if (!ok) { for (uint8_t i = 0; i < MAX_STUDENTS; i++) resetStudent(i, false); saveAll(); }
}

void pushSession(uint8_t i, uint8_t pct) {
  Student &s = students[i];
  if (s.histN < HIST_LEN) s.hist[s.histN++] = pct;
  else { for (uint8_t k = 1; k < HIST_LEN; k++) s.hist[k - 1] = s.hist[k]; s.hist[HIST_LEN - 1] = pct; }
  if (pct > s.bestPct) s.bestPct = pct;
  saveAll();
}

// ───────────────────────── QUESTION MODEL ─────────────────────────
struct Question {
  String  text;       // what the OLED shows
  long    answer;
  uint8_t topic;      // T_ADD ...
  int     aud1, audOp, aud2;   // audio tracks; aud1 = -1 means "unary" (NOT)
  bool    binary;     // logic question -> answer is 0/1, auto-submit
};

// ── Arithmetic ──────────────────────────────────────────────
//  সহজ    : 1-digit যোগ (carry নেই), 1-digit বিয়োগ (borrow নেই)
//  মাঝারি : 2-digit যোগ (carry সহ), 2-digit বিয়োগ (borrow সহ), নামতা ২-১০
//  কঠিন   : 2-digit × 1-digit, বড় যোগ/বিয়োগ, নিঃশেষে ভাগ
Question makeArith(uint8_t diff) {
  Question q; q.binary = false; q.aud1 = q.aud2 = q.audOp = -1;
  long a, b;
  String opStr;

  if (diff == 0) {                                  // সহজ
    if (random(0, 2) == 0) {
      a = random(1, 9); b = random(1, 10 - a);      // a+b <= 9, no carry
      q.answer = a + b; q.topic = T_ADD; opStr = "+"; q.audOp = A_PLUS;
    } else {
      a = random(2, 10); b = random(1, a);          // no borrow
      q.answer = a - b; q.topic = T_SUB; opStr = "-"; q.audOp = A_MINUS;
    }
  }
  else if (diff == 1) {                             // মাঝারি
    uint8_t pick = random(0, 3);
    if (pick == 0)      { a = random(10, 90); b = random(10, 90);
                          q.answer = a + b; q.topic = T_ADD; opStr = "+"; q.audOp = A_PLUS; }
    else if (pick == 1) { a = random(20, 99); b = random(10, a);
                          q.answer = a - b; q.topic = T_SUB; opStr = "-"; q.audOp = A_MINUS; }
    else                { a = random(2, 11); b = random(2, 11);
                          q.answer = a * b; q.topic = T_MUL; opStr = "×"; q.audOp = A_TIMES; }
  }
  else {                                            // কঠিন
    uint8_t pick = random(0, 4);
    if (pick == 0)      { a = random(45, 99); b = random(45, 99);
                          q.answer = a + b; q.topic = T_ADD; opStr = "+"; q.audOp = A_PLUS; }
    else if (pick == 1) { a = random(50, 99); b = random(11, 50);
                          q.answer = a - b; q.topic = T_SUB; opStr = "-"; q.audOp = A_MINUS; }
    else if (pick == 2) { a = random(11, 40); b = random(3, 10);
                          q.answer = a * b; q.topic = T_MUL; opStr = "×"; q.audOp = A_TIMES; }
    else                { b = random(2, 10); long r = random(2, 11); a = b * r;
                          q.answer = r; q.topic = T_DIV; opStr = "÷"; q.audOp = A_DIV; }
  }

  q.aud1 = (int)a; q.aud2 = (int)b;
  q.text = toBanglaNum(String(a)) + " " + opStr + " " + toBanglaNum(String(b)) + " = ?";
  return q;
}

// ── 1-bit Logic ─────────────────────────────────────────────
//  সহজ    : AND, OR
//  মাঝারি : + NOT, NAND, NOR
//  কঠিন   : + XOR, XNOR
enum { L_AND = 0, L_OR, L_NOT, L_NAND, L_NOR, L_XOR, L_XNOR };
const char *L_NAME[]  = {"AND", "OR", "NOT", "NAND", "NOR", "XOR", "XNOR"};
const int   L_AUDIO[] = {A_AND, A_OR, A_NOT, A_NAND, A_NOR, A_XOR, A_XNOR};

Question makeLogic(uint8_t diff) {
  Question q; q.binary = true; q.topic = T_LOGIC;
  uint8_t pool = (diff == 0) ? 2 : (diff == 1 ? 5 : 7);
  uint8_t op = random(0, pool);
  int a = random(0, 2), b = random(0, 2);

  switch (op) {
    case L_AND:  q.answer = a & b;         break;
    case L_OR:   q.answer = a | b;         break;
    case L_NOT:  q.answer = !a;            break;
    case L_NAND: q.answer = !(a & b);      break;
    case L_NOR:  q.answer = !(a | b);      break;
    case L_XOR:  q.answer = a ^ b;         break;
    case L_XNOR: q.answer = !(a ^ b);      break;
  }

  q.audOp = L_AUDIO[op];
  if (op == L_NOT) {
    q.text = String("NOT ") + a + " = ?";
    q.aud1 = -1; q.aud2 = a;
  } else {
    q.text = String(a) + " " + L_NAME[op] + " " + b + " = ?";
    q.aud1 = a; q.aud2 = b;
  }
  return q;
}

void speakQuestion(const Question &q) {
  if (q.aud1 >= 0) { sayNumber(q.aud1); }
  audioSay(q.audOp, 950);
  sayNumber(q.aud2);
  audioSay(A_EQUALS, 1100);
}

// ───────────────────────── ANSWER ENTRY ─────────────────────────
//  return codes: 1 = correct, 2 = wrong, 3 = timeout, 9 = user quit
uint8_t askAndGrade(const Question &q, int16_t limitSec, uint8_t qIdx, uint8_t qTotal) {
  String typed = "";
  uint32_t t0 = millis();
  int16_t lastShown = -2;
  bool submitted = false;

  live.q = q.text; live.typed = ""; live.qIdx = qIdx; live.qTotal = qTotal; live.lastRes = 0;

  screenQuestion(q.text, typed, 0, limitSec, limitSec, qIdx, qTotal);
  speakQuestion(q);

  while (!submitted) {
    int16_t left = -1;
    if (limitSec > 0) {
      int32_t used = (millis() - t0) / 1000;
      left = limitSec - used;
      if (left <= 0) {
        live.secLeft = 0;
        return 3;                                   // সময় শেষ
      }
    }
    live.secLeft = left;

    if (left != lastShown) {
      screenQuestion(q.text, typed, 0, left, limitSec, qIdx, qTotal);
      lastShown = left;
    }

    if (remote.start) return 9;               // নতুন সেশন চাওয়া হয়েছে

    char k = getKeyLive();
    if (!k) { delay(4); continue; }

    if (k == '#') { submitted = true; }
    else if (k == '*') { typed = ""; live.typed = ""; lastShown = -2; beep(15); }
    else if (k == 'D') { return 9; }
    else if (k >= '0' && k <= '9') {
      if (q.binary) {
        if (k != '0' && k != '1') { beep(200); continue; }   // binary মোডে শুধু ০/১
        typed = String(k); live.typed = typed;
        screenQuestion(q.text, typed, 0, left, limitSec, qIdx, qTotal);
        beep(15); serviceDelay(220);
        submitted = true;                                    // auto-submit
      } else if (typed.length() < 5) {
        typed += k; live.typed = typed; lastShown = -2; beep(15);
      }
    }
  }

  if (typed.length() == 0) return 2;
  return (typed.toInt() == q.answer) ? 1 : 2;
}

void feedback(const Question &q, uint8_t res, const String &typed) {
  live.lastRes = res;
  if (res == 1) {
    screenQuestion(q.text, typed, 1, -1, -1, live.qIdx, live.qTotal);
    digitalWrite(GREEN_LED, HIGH); beep(120);
    audioSay(A_RIGHT, 1500);
    digitalWrite(GREEN_LED, LOW);
  } else {
    screenQuestion(q.text, typed, 2, -1, -1, live.qIdx, live.qTotal);
    digitalWrite(RED_LED, HIGH); beep(400);
    audioSay(res == 3 ? A_TIMEUP : A_WRONG, 1400);
    digitalWrite(RED_LED, LOW);
  }
}

void revealAnswer(const Question &q) {
  String ans = q.binary ? String(q.answer) : toBanglaNum(String(q.answer));
  String shown = String("= ");
  shown += ans;
  screenMsg(q.text, shown);
  audioSay(A_ANSWERIS, 900);
  sayNumber(q.answer);
  serviceDelay(1400);
}

// ───────────────────────── SESSIONS ─────────────────────────
int16_t timeLimitFor(uint8_t mode, uint8_t diff) {
  if (mode == 0) { if (diff == 0) return 0; return diff == 1 ? 25 : 18; }   // গণিত
  else           { if (diff == 0) return 0; return diff == 1 ? 15 : 10; }   // লজিক
}

void runLearning(uint8_t mode, uint8_t diff) {
  audioSay(A_LEARN, 1200);
  for (uint8_t i = 1; i <= QUIZ_LEN; i++) {
    Question q = (mode == 0) ? makeArith(diff) : makeLogic(diff);
    uint8_t res = askAndGrade(q, 0, i, QUIZ_LEN);        // no timer while learning
    if (res == 9) return;
    feedback(q, res, live.typed);
    revealAnswer(q);                                     // শেখার সময় উত্তর দেখিয়ে দেয়
    serviceDelay(600);
  }
  screenMsg("শেষ", "আরো শিখি?");
  audioSay(A_DONE, 1800);
  serviceDelay(1200);
}

void runTest(uint8_t mode, uint8_t diff) {
  audioSay(A_TEST, 1200);
  int16_t limit = timeLimitFor(mode, diff);
  uint8_t cor = 0;
  Student &s = students[curStudent];

  for (uint8_t i = 1; i <= QUIZ_LEN; i++) {
    Question q = (mode == 0) ? makeArith(diff) : makeLogic(diff);
    uint8_t res = askAndGrade(q, limit, i, QUIZ_LEN);
    if (res == 9) return;

    feedback(q, res, live.typed);
    if (res != 1) revealAnswer(q);

    s.tTot++; s.topTot[q.topic]++;
    if (res == 1) { cor++; s.tCor++; s.topCor[q.topic]++; live.cor++; }
    else          { live.wrg++; }
    serviceDelay(500);
  }

  uint8_t pct = (cor * 100) / QUIZ_LEN;
  pushSession(curStudent, pct);

  String scoreLine = String("সঠিক ");
  scoreLine += toBanglaNum(String(cor));
  scoreLine += "/";
  scoreLine += toBanglaNum(String(QUIZ_LEN));
  String pctLine = toBanglaNum(String(pct));
  pctLine += "%";
  screenMsg("ফলাফল", scoreLine, pctLine);
  audioSay(A_DONE, 1400);
  audioSay(pct >= 60 ? A_GREAT : A_TRYAGAIN, 1800);
  serviceDelay(1500);
}

// ───────────────────────── TEACHER DASHBOARD ─────────────────────────
static const char PAGE_HTML[] PROGMEM = R"HTML(<!DOCTYPE html><html lang="bn"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>গণিত যন্ত্র — শিক্ষকের পাতা</title><style>
:root{
  --slate:#123B33; --slate2:#0C2A24; --paper:#FDF6E3; --ink:#22302C;
  --mango:#F6A623; --melon:#E8505B; --sky:#2E86AB; --leaf:#6BBF59; --chalk:#EAF4EF;
}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--paper);color:var(--ink);
  font-family:'Hind Siliguri','Noto Sans Bengali','SolaimanLipi','Segoe UI',sans-serif;
  line-height:1.65;padding-bottom:56px}
.wrap{max-width:920px;margin:0 auto;padding:0 18px}

/* hero: a chalk slate showing what the child is doing right now */
.slate{background:var(--slate);color:var(--chalk);border-radius:0 0 34px 34px;
  padding:26px 18px 34px;box-shadow:inset 0 -6px 0 rgba(0,0,0,.25)}
.slate h1{font-size:1.35rem;font-weight:700;letter-spacing:.2px}
.slate h1 span{opacity:.6;font-weight:400;font-size:.95rem;display:block;margin-top:2px}
.now{margin-top:20px;border:3px dashed rgba(234,244,239,.35);border-radius:24px;
  padding:22px 18px;text-align:center}
.now .q{font-size:2.6rem;font-weight:700;letter-spacing:1px;min-height:1.2em}
.now .meta{opacity:.72;font-size:.95rem;margin-top:8px}
.now .typed{margin-top:10px;font-size:1.2rem}
.pill{display:inline-block;padding:3px 14px;border-radius:999px;font-size:.85rem;margin:0 4px}
.on{background:var(--leaf);color:#0C2A24}.off{background:rgba(234,244,239,.18)}
.clock{font-size:1.1rem;margin-top:10px;color:var(--mango)}

/* student chips */
.kids{display:flex;gap:10px;overflow-x:auto;padding:20px 0 6px}
.kid{flex:0 0 auto;background:#fff;border:2px solid #E4DAC0;border-radius:18px;
  padding:9px 16px;cursor:pointer;font-size:1rem;white-space:nowrap}
.kid.sel{background:var(--slate);color:var(--chalk);border-color:var(--slate)}
.kid.live::after{content:"●";color:var(--leaf);margin-right:6px;font-size:.8rem}

/* stat tiles */
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-top:8px}
.tile{background:#fff;border-radius:20px;padding:16px 18px;border-bottom:6px solid var(--mango)}
.tile b{display:block;font-size:2.1rem;line-height:1.1}
.tile small{opacity:.65;font-size:.9rem}
.t2{border-color:var(--leaf)}.t3{border-color:var(--melon)}.t4{border-color:var(--sky)}

.panel{background:#fff;border-radius:24px;padding:20px;margin-top:16px}
.panel h2{font-size:1.05rem;font-weight:700;margin-bottom:4px}
.panel p{font-size:.88rem;opacity:.62;margin-bottom:14px}
canvas{width:100%;height:auto;display:block}

.tools{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}
button{font-family:inherit;font-size:.95rem;border:none;border-radius:14px;
  padding:11px 20px;cursor:pointer;background:var(--slate);color:var(--chalk)}
button.ghost{background:transparent;color:var(--ink);border:2px solid #E4DAC0}
button:focus-visible{outline:3px solid var(--mango);outline-offset:2px}
.empty{opacity:.55;font-size:.95rem;padding:22px 0;text-align:center}

/* remote control: looks like a row of chalk switches, not a form */
.ctl{background:var(--slate);color:var(--chalk);border-radius:24px;padding:20px;margin-top:16px}
.ctl h2{font-size:1.05rem;margin-bottom:4px}
.ctl p{font-size:.88rem;opacity:.6;margin-bottom:16px}
.row{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px}
.row>span{width:82px;opacity:.7;font-size:.9rem}
.sw{border:2px solid rgba(234,244,239,.3);background:none;color:var(--chalk);
  border-radius:999px;padding:7px 18px;font-size:.95rem}
.sw.on{background:var(--mango);border-color:var(--mango);color:#0C2A24}
.go{background:var(--leaf);color:#0C2A24;font-size:1.05rem;padding:13px 28px;width:100%;margin-top:6px}
.go:disabled{opacity:.45;cursor:not-allowed}
@media(prefers-reduced-motion:no-preference){.kid{transition:background .15s}}
</style></head><body>

<div class="slate"><div class="wrap">
  <h1>গণিত শেখার যন্ত্র<span>শিক্ষকের পাতা</span></h1>
  <div class="now">
    <div class="q" id="q">—</div>
    <div class="typed" id="typed"></div>
    <div class="clock" id="clock"></div>
    <div class="meta" id="meta">যন্ত্রটি এখন বিশ্রামে আছে</div>
  </div>
</div></div>

<div class="wrap">
  <div class="kids" id="kids"></div>

  <div class="tiles">
    <div class="tile"><small>মোট প্রশ্ন</small><b id="k1">0</b></div>
    <div class="tile t2"><small>সঠিক</small><b id="k2">0</b></div>
    <div class="tile t3"><small>ভুল</small><b id="k3">0</b></div>
    <div class="tile t4"><small>নির্ভুলতা</small><b id="k4">0%</b></div>
  </div>

  <div class="panel">
    <h2>কোন বিষয়ে কেমন পারছে</h2>
    <p>প্রতিটি বিষয়ে সঠিক উত্তরের হার</p>
    <canvas id="bars" width="880" height="300"></canvas>
    <div class="empty" id="barsEmpty" hidden>এখনো কোনো পরীক্ষা হয়নি</div>
  </div>

  <div class="panel">
    <h2>উন্নতির ধারা</h2>
    <p>শেষ ১২টি পরীক্ষার ফলাফল, ক্রম অনুসারে</p>
    <canvas id="line" width="880" height="300"></canvas>
    <div class="empty" id="lineEmpty" hidden>অন্তত দুটি পরীক্ষা শেষ হলে ধারা দেখা যাবে</div>
  </div>

  <div class="ctl">
    <h2>যন্ত্র চালান এখান থেকে</h2>
    <p>বেছে নিয়ে শুরু দিলে যন্ত্রের মেনু পেরিয়ে সরাসরি ওই সেশন চালু হবে</p>
    <div class="row"><span>শিশু</span><div id="cStudent"></div></div>
    <div class="row"><span>বিষয়</span><div id="cMode"></div></div>
    <div class="row"><span>ধাপ</span><div id="cPhase"></div></div>
    <div class="row"><span>কঠিনতা</span><div id="cDiff"></div></div>
    <button class="go" id="go" onclick="go()">যন্ত্রে শুরু করুন</button>
  </div>

  <div class="tools">
    <button onclick="rename()">নাম বদলান</button>
    <button class="ghost" onclick="wipe()">এই শিশুর হিসাব মুছুন</button>
  </div>
</div>

<script>
const TOPICS=['যোগ','বিয়োগ','গুণ','ভাগ','লজিক'];
const COLORS=['#F6A623','#E8505B','#2E86AB','#6BBF59','#9B6BBF'];
let D=null, sel=0;

function css(v){return getComputedStyle(document.documentElement).getPropertyValue(v).trim()}
function fit(c){const r=window.devicePixelRatio||1,w=c.clientWidth;
  c.width=w*r;c.height=300*r;const x=c.getContext('2d');x.setTransform(r,0,0,r,0,0);
  x.clearRect(0,0,w,300);return[x,w,300]}

function bars(s){
  const [x,W,H]=fit(document.getElementById('bars'));
  const any=s.topTot.some(v=>v>0);
  document.getElementById('barsEmpty').hidden=any;
  document.getElementById('bars').hidden=!any;
  if(!any)return;
  const pad=34,base=H-46,n=TOPICS.length,gap=W/n;
  x.strokeStyle='#E4DAC0';x.lineWidth=1;
  for(let g=0;g<=4;g++){const y=pad+(base-pad)*g/4;
    x.beginPath();x.moveTo(0,y);x.lineTo(W,y);x.stroke();}
  x.font='500 14px "Hind Siliguri",sans-serif';x.textAlign='center';
  for(let i=0;i<n;i++){
    const t=s.topTot[i],c=s.topCor[i],p=t?Math.round(c*100/t):0;
    const bw=Math.min(60,gap*.5),cx=gap*i+gap/2,h=(base-pad)*p/100;
    x.fillStyle=t?COLORS[i]:'#E9E1CC';
    x.beginPath();x.roundRect(cx-bw/2,base-h,bw,Math.max(h,3),[10,10,0,0]);x.fill();
    x.fillStyle=css('--ink');
    if(t){x.fillText(p+'%',cx,base-h-9);}
    x.globalAlpha=t?1:.45;
    x.fillText(TOPICS[i],cx,base+22);
    x.globalAlpha=.5;x.font='400 12px "Hind Siliguri",sans-serif';
    x.fillText(t?(c+'/'+t):'—',cx,base+40);
    x.globalAlpha=1;x.font='500 14px "Hind Siliguri",sans-serif';
  }
}

function line(s){
  const h=s.hist||[];
  const [x,W,H]=fit(document.getElementById('line'));
  document.getElementById('lineEmpty').hidden=h.length>=2;
  document.getElementById('line').hidden=h.length<2;
  if(h.length<2)return;
  const L=40,R=12,T=26,B=44,w=W-L-R,ht=H-T-B;
  x.strokeStyle='#E4DAC0';x.lineWidth=1;
  x.font='400 12px "Hind Siliguri",sans-serif';x.fillStyle='#8A8577';x.textAlign='right';
  for(let g=0;g<=4;g++){const v=100-g*25,y=T+ht*g/4;
    x.beginPath();x.moveTo(L,y);x.lineTo(W-R,y);x.stroke();x.fillText(v,L-8,y+4);}
  const px=i=>L+w*i/(h.length-1), py=v=>T+ht*(1-v/100);
  x.beginPath();x.moveTo(px(0),py(h[0]));
  for(let i=1;i<h.length;i++)x.lineTo(px(i),py(h[i]));
  x.strokeStyle=css('--slate');x.lineWidth=3;x.lineJoin='round';x.stroke();
  x.lineTo(px(h.length-1),T+ht);x.lineTo(L,T+ht);x.closePath();
  x.fillStyle='rgba(18,59,51,.08)';x.fill();
  x.textAlign='center';
  for(let i=0;i<h.length;i++){
    x.beginPath();x.arc(px(i),py(h[i]),5,0,7);
    x.fillStyle=h[i]>=60?css('--leaf'):css('--melon');x.fill();
    x.fillStyle='#8A8577';x.fillText(i+1,px(i),H-14);
  }
}

function draw(){
  if(!D)return;
  const s=D.students[sel];
  document.getElementById('kids').innerHTML=D.students.map((v,i)=>
    `<div class="kid ${i==sel?'sel':''} ${D.live.student==i&&D.live.active?'live':''}" onclick="pick(${i})">${v.name}</div>`).join('');
  document.getElementById('k1').textContent=s.tTot;
  document.getElementById('k2').textContent=s.tCor;
  document.getElementById('k3').textContent=s.tTot-s.tCor;
  document.getElementById('k4').textContent=(s.tTot?Math.round(s.tCor*100/s.tTot):0)+'%';

  const l=D.live;
  document.getElementById('q').textContent=l.active?l.q:'—';
  document.getElementById('typed').textContent=l.active&&l.typed?('উত্তর: '+l.typed):'';
  document.getElementById('clock').textContent=(l.active&&l.secLeft>=0)?('বাকি সময় '+l.secLeft+' সেকেন্ড'):'';
  document.getElementById('meta').innerHTML=l.active
    ? `<span class="pill on">${D.students[l.student].name}</span>
       <span class="pill off">${l.mode}</span><span class="pill off">${l.phase}</span>
       <span class="pill off">${l.diff}</span><span class="pill off">প্রশ্ন ${l.qIdx}/${l.qTotal}</span>`
    : 'যন্ত্রটি এখন বিশ্রামে আছে';

  bars(s);line(s);drawCtl();
}
function pick(i){sel=i;draw()}

const MODES=['গণিত','লজিক'],PHASES=['শিখি','যাচাই'],DIFFS=['সহজ','মাঝারি','কঠিন'];
let R={student:0,mode:0,phase:0,diff:0};
function sw(hostId,list,key){
  document.getElementById(hostId).innerHTML=list.map((t,i)=>
    `<button class="sw ${R[key]==i?'on':''}" onclick="setR('${key}',${i})">${t}</button>`).join(' ');
}
function drawCtl(){
  sw('cStudent',D.students.map(v=>v.name),'student');
  sw('cMode',MODES,'mode');sw('cPhase',PHASES,'phase');sw('cDiff',DIFFS,'diff');
  const b=document.getElementById('go');
  b.disabled=D.live.active;
  b.textContent=D.live.active?'এখন একটি সেশন চলছে':'যন্ত্রে শুরু করুন';
}
function setR(k,v){R[k]=v;drawCtl();
  fetch(`/api/set?student=${R.student}&mode=${R.mode}&phase=${R.phase}&diff=${R.diff}`);}
function go(){
  fetch(`/api/set?student=${R.student}&mode=${R.mode}&phase=${R.phase}&diff=${R.diff}&start=1`);
  const b=document.getElementById('go');b.disabled=true;b.textContent='যন্ত্রে পাঠানো হলো';
}
let first=true;
async function tick(){try{
  D=await(await fetch('/api/data')).json();
  if(first&&D.remote){R={student:D.remote.student,mode:D.remote.mode,
    phase:D.remote.phase,diff:D.remote.diff};sel=R.student;first=false;}
  draw()}catch(e){}}
async function rename(){
  const v=prompt('নতুন নাম লিখুন',D.students[sel].name);
  if(v&&v.trim()){await fetch('/api/name?i='+sel+'&n='+encodeURIComponent(v.trim()));tick()}
}
async function wipe(){
  if(confirm(D.students[sel].name+' — এর সব হিসাব মুছে যাবে। চালিয়ে যাবেন?')){
    await fetch('/api/reset?i='+sel);tick()}
}
tick();setInterval(tick,1500);
window.addEventListener('resize',draw);
</script></body></html>)HTML";

const char *MODE_BN[]  = {"গণিত", "লজিক"};
const char *PHASE_BN[] = {"শিখি", "যাচাই"};
const char *DIFF_BN[]  = {"সহজ", "মাঝারি", "কঠিন"};

void handleRoot() { server.send_P(200, "text/html; charset=utf-8", PAGE_HTML); }

String jsonEscape(const char *s) {
  String o = "";
  for (const char *p = s; *p; p++) {
    if (*p == '"' || *p == '\\') { o += '\\'; o += *p; }
    else if ((uint8_t)*p < 0x20) continue;
    else o += *p;
  }
  return o;
}

void handleData() {
  String j = "{\"students\":[";
  for (uint8_t i = 0; i < MAX_STUDENTS; i++) {
    Student &s = students[i];
    if (i) j += ",";
    j += "{\"name\":\"";  j += jsonEscape(s.name);
    j += "\",\"tTot\":";  j += s.tTot;
    j += ",\"tCor\":";     j += s.tCor;
    j += ",\"best\":";     j += s.bestPct;
    j += ",\"topTot\":[";
    for (uint8_t t = 0; t < T_COUNT; t++) { if (t) j += ","; j += s.topTot[t]; }
    j += "],\"topCor\":[";
    for (uint8_t t = 0; t < T_COUNT; t++) { if (t) j += ","; j += s.topCor[t]; }
    j += "],\"hist\":[";
    for (uint8_t h = 0; h < s.histN; h++) { if (h) j += ","; j += s.hist[h]; }
    j += "]}";
  }
  j += "],\"live\":{\"active\":";  j += (live.active ? "true" : "false");
  j += ",\"student\":";             j += (int)live.student;
  j += ",\"mode\":\"";             j += MODE_BN[live.mode];
  j += "\",\"phase\":\"";         j += PHASE_BN[live.phase];
  j += "\",\"diff\":\"";          j += DIFF_BN[live.diff];
  j += "\",\"q\":\"";             j += live.q;
  j += "\",\"typed\":\"";         j += live.typed;
  j += "\",\"qIdx\":";             j += live.qIdx;
  j += ",\"qTotal\":";              j += live.qTotal;
  j += ",\"secLeft\":";             j += (int)live.secLeft;
  j += "},\"remote\":{\"student\":"; j += (int)remote.student;
  j += ",\"mode\":";  j += remote.mode;
  j += ",\"phase\":"; j += remote.phase;
  j += ",\"diff\":";  j += remote.diff;
  j += ",\"armed\":"; j += (remote.start ? "true" : "false");
  j += "}}";
  server.send(200, "application/json; charset=utf-8", j);
}

void handleName() {
  int i = server.arg("i").toInt();
  String n = server.arg("n");
  if (i >= 0 && i < MAX_STUDENTS && n.length()) {
    strncpy(students[i].name, n.c_str(), sizeof(students[i].name) - 1);
    students[i].name[sizeof(students[i].name) - 1] = 0;
    saveAll();
  }
  server.send(200, "text/plain", "ok");
}

void handleReset() {
  int i = server.arg("i").toInt();
  if (i >= 0 && i < MAX_STUDENTS) { resetStudent(i, true); saveAll(); }
  server.send(200, "text/plain", "ok");
}

void handleSet() {
  if (server.hasArg("student")) {
    int v = server.arg("student").toInt();
    if (v >= 0 && v < MAX_STUDENTS) remote.student = v;
  }
  if (server.hasArg("mode"))  remote.mode  = constrain(server.arg("mode").toInt(),  0, 1);
  if (server.hasArg("phase")) remote.phase = constrain(server.arg("phase").toInt(), 0, 1);
  if (server.hasArg("diff"))  remote.diff  = constrain(server.arg("diff").toInt(),  0, 2);
  if (server.arg("start") == "1") remote.start = true;
  server.send(200, "text/plain", "ok");
}

void configModeCallback(WiFiManager *wm) {
  screenMsg("ফোন যোগ করো", "Smart_Trainer");
}

// ───────────────────────── SETUP ─────────────────────────
void setup() {
  Serial.begin(115200);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  randomSeed(analogRead(SEED_PIN) ^ micros());

  Wire.begin(21, 22);
  u8g2.begin();
  u8g2.enableUTF8Print();

  screenMsg("গণিত খেলা", "চালু হবে");
  delay(500);

  screenMsg("অডিও", "দেখা হলো");
  initAudio();
  screenMsg("অডিও", dfOK ? "ঠিক আছে" : "ভুল আছে");
  delay(700);

  loadAll();

  screenMsg("ওয়াইফাই", "যোগ হবে");
  WiFiManager wm;
  wm.setAPCallback(configModeCallback);
  wm.setConnectTimeout(15);
  wm.setConfigPortalTimeout(180);
  if (!wm.autoConnect("Smart_Trainer")) {
    screenMsg("ওয়াইফাই", "পাওয়া যায়নি");
    delay(2500);
    ESP.restart();
  }

  server.on("/",           handleRoot);
  server.on("/api/data",   handleData);
  server.on("/api/name",   handleName);
  server.on("/api/reset",  handleReset);
  server.on("/api/set",    handleSet);
  server.begin();

  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_7x14B_tr);
  u8g2.setCursor(0, 20); u8g2.print("Dashboard at");
  u8g2.setCursor(0, 42); u8g2.print(WiFi.localIP());
  u8g2.sendBuffer();

  audioSay(A_WELCOME, 1600);
  serviceDelay(1800);
}

// ───────────────────────── MAIN FLOW ─────────────────────────
void showAddress() {
  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_7x14B_tr);
  u8g2.setCursor(0, 18); u8g2.print("Open in browser:");
  u8g2.setCursor(0, 40); u8g2.print(WiFi.localIP());
  u8g2.setFont(u8g2_font_4x6_tr);
  u8g2.setCursor(0, 62); u8g2.print("press any key");
  u8g2.sendBuffer();
  while (!getKeyLive()) delay(5);
}

void runSession(uint8_t mode, uint8_t phase, uint8_t diff) {
  live.active  = true;  live.student = curStudent;
  live.mode    = mode;  live.phase   = phase;  live.diff = diff;
  live.cor = live.wrg = 0; live.qIdx = 0; live.qTotal = QUIZ_LEN;

  screenMsg("শুরু", MODE_BN[mode], DIFF_BN[diff]);
  serviceDelay(1200);

  if (phase == 0) runLearning(mode, diff);
  else            runTest(mode, diff);

  live.active = false; live.secLeft = -1; live.q = ""; live.typed = "";
  serviceDelay(600);
}

void loop() {
  server.handleClient();

  live.active = false; live.q = ""; live.typed = ""; live.secLeft = -1;

  // ── শিক্ষক ড্যাশবোর্ড থেকে শুরু করলে মেনু পুরো বাদ ──
  if (remote.start) {
    remote.start = false;
    curStudent = remote.student;
    beep(60);
    runSession(remote.mode, remote.phase, remote.diff);
    return;
  }

  // ── ১. কে খেলবে ──
  const char *kidNames[MAX_STUDENTS + 1];
  for (uint8_t i = 0; i < MAX_STUDENTS; i++) kidNames[i] = students[i].name;
  kidNames[MAX_STUDENTS] = "ঠিকানা";                 // shows the dashboard IP

  int pick = menuSelect("কে খেলবে?", kidNames, MAX_STUDENTS + 1, curStudent);
  if (pick < 0) return;                              // -1 back, -2 remote took over
  if (pick == MAX_STUDENTS) { showAddress(); return; }
  curStudent = pick;

  // ── ২. কোন বিষয় ──
  int mode = menuSelect("বিষয় বাছাই", MODE_BN, 2, 0);
  if (mode < 0) return;
  audioSay(mode == 0 ? A_MATH : A_LOGIC, 900);

  // ── ৩. শিখি না যাচাই ──
  int phase = menuSelect("কী করবে?", PHASE_BN, 2, 0);
  if (phase < 0) return;

  // ── ৪. কতটা কঠিন ──
  int diff = menuSelect("কেমন কঠিন?", DIFF_BN, 3, 0);
  if (diff < 0) return;
  audioSay(diff == 0 ? A_EASY : (diff == 1 ? A_MEDIUM : A_HARD), 1000);

  runSession(mode, phase, diff);
}

/**********************************************************************
 *  BN_SAFE_WORDS — ফন্ট ভাঙা এড়াতে
 *  ------------------------------------------------------------------
 *  u8g2_font_unifont_t_bengali কোনো যুক্তবর্ণ (ligature) জোড়া লাগাতে
 *  পারে না — হসন্ত আলাদা বাক্স হয়ে দেখা যায়। তাই OLED-এ যাওয়া প্রতিটি
 *  শব্দ যুক্তবর্ণ-মুক্ত রাখা হয়েছে।
 *
 *  এড়িয়ে চলুন : ক্ষ  ত্র  প্র  ষ্ট  স্ট  ন্ত  ব্দ  চ্ছ  ত্ত  ন্ড  র্‌(রেফ)
 *  নিরাপদ শব্দ : গণিত লজিক শিখি যাচাই সহজ মাঝারি কঠিন যোগ বিয়োগ গুণ ভাগ
 *                সঠিক ভুল মোট সময় ফলাফল শুরু শেষ আবার পাতা ঠিকানা
 *                দারুণ ভালো হয়েছে হয়নি খেলবে বাছাই ওয়াইফাই অডিও শিশু
 *
 *  ওয়েব ড্যাশবোর্ডে এই সীমা নেই — সেখানে ব্রাউজারের ফন্ট সব যুক্তবর্ণ
 *  ঠিকভাবে দেখায়, তাই পুরো স্বাভাবিক বাংলা লেখা হয়েছে।
 **********************************************************************/
