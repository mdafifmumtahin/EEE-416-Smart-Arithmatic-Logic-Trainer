#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <Keypad.h>
#include "DFRobotDFPlayerMini.h"
#include <U8g2lib.h> 
#include <WiFiManager.h> // ডাইনামিক ওয়াই-ফাইয়ের জন্য নতুন লাইব্রেরি

WebServer server(80);
HardwareSerial mySoftwareSerial(2); 
DFRobotDFPlayerMini myDFPlayer;

U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, /* reset=*/ U8X8_PIN_NONE);

#define GREEN_LED 18
#define RED_LED 19
#define BUZZER 23

const byte ROWS = 4; 
const byte COLS = 4; 
char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};
byte rowPins[ROWS] = {13, 12, 14, 27}; 
byte colPins[COLS] = {26, 25, 33, 32}; 
Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

int totalQuestions = 0;
int correctAnswers = 0;
int wrongAnswers = 0;
int currentQIndex = 0;
bool quizFinished = false;

// ইংরেজি নাম্বারকে বাংলায় কনভার্ট করার ম্যাজিক ফাংশন
String toBanglaNum(String enStr) {
  String bnStr = "";
  for (int i = 0; i < enStr.length(); i++) {
    switch (enStr[i]) {
      case '0': bnStr += "০"; break;
      case '1': bnStr += "১"; break;
      case '2': bnStr += "২"; break;
      case '3': bnStr += "৩"; break;
      case '4': bnStr += "৪"; break;
      case '5': bnStr += "৫"; break;
      case '6': bnStr += "৬"; break;
      case '7': bnStr += "৭"; break;
      case '8': bnStr += "৮"; break;
      case '9': bnStr += "৯"; break;
      default: bnStr += enStr[i]; break; // যোগ/বিয়োগ চিহ্নের জন্য
    }
  }
  return bnStr;
}

// OLED স্ক্রিন আপডেট করার ফাংশন (আপডেটেড)
void updateOLED(String line1, String line2, int status = 0, bool isSystemMsg = false) {
  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_unifont_t_bengali); // এই ফন্টেই ইংরেজি ও বাংলা দুটোই সাপোর্ট করবে
  
  // প্রথম লাইন প্রিন্ট (প্রশ্ন বা সিস্টেম মেসেজ)
  u8g2.setCursor(0, 25);
  u8g2.print(line1);
  
  // দ্বিতীয় লাইন প্রিন্ট
  u8g2.setCursor(0, 55);
  
  if (!isSystemMsg) {
    // কুইজ চলাকালীন সময় (বাংলা নাম্বার ও উঃ)
    u8g2.print("উঃ "); 
    u8g2.print(toBanglaNum(line2)); 

    if (status == 1) {
      u8g2.print(" ✔");
    } else if (status == 2) {
      u8g2.print(" ✖");
    }
  } else {
    // সিস্টেম মেসেজ বা কুইজ শেষের সময় (শুধুমাত্র নরমাল টেক্সট)
    u8g2.print(line2); 
  }
  
  u8g2.sendBuffer(); 
}

// ওয়াই-ফাই ফেইল করলে স্ক্রিনে হটস্পটের মেসেজ দেখানোর ফাংশন
void configModeCallback (WiFiManager *myWiFiManager) {
  updateOLED("Connect Phone to:", "Smart_Trainer", 0, true);
}

// ================= ওয়েব সার্ভার =================
void handleRoot() {
  String html = "<!DOCTYPE html><html lang='bn'><head>";
  html += "<meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'>";
  html += "<meta http-equiv='refresh' content='2'> "; 
  html += "<title>EEE 416 Teacher Dashboard</title>";
  html += "<style>body { background-color: #E0F7FA; font-family: 'Comic Sans MS', sans-serif; text-align: center; color: #333; margin: 0; padding: 20px; }";
  html += "h1 { color: #00796B; font-size: 32px; } .container { display: flex; flex-wrap: wrap; justify-content: center; gap: 20px; margin-top: 30px; }";
  html += ".card { background: white; border-radius: 25px; padding: 25px; width: 220px; box-shadow: 0 10px 20px rgba(0,0,0,0.1); border: 4px dashed #ccc; }";
  html += ".card h2 { font-size: 50px; margin: 10px 0; } .card p { font-size: 22px; font-weight: bold; margin: 0; }</style></head><body>";
  html += "<h1>🌟 EEE 416 Smart Trainer Dashboard 🌟</h1><div class='container'>";
  html += "<div class='card' style='border-color: #FFC107; color: #FF9800; background-color: #FFFDE7;'><p>মোট প্রশ্ন 📝</p><h2>" + String(totalQuestions) + "</h2></div>";
  html += "<div class='card' style='border-color: #4CAF50; color: #388E3C; background-color: #E8F5E9;'><p>সঠিক উত্তর ✔️</p><h2>" + String(correctAnswers) + "</h2></div>";
  html += "<div class='card' style='border-color: #FF5252; color: #D32F2F; background-color: #FFEBEE;'><p>ভুল উত্তর ❌</p><h2>" + String(wrongAnswers) + "</h2></div>";
  html += "</div><br><br><div>👶 Designed for fun learning! (Randomized) 👶</div></body></html>";
  server.send(200, "text/html", html);
}

void setup() {
  Serial.begin(115200);
  
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);

  randomSeed(analogRead(34)); 
  mySoftwareSerial.begin(9600, SERIAL_8N1, 16, 17);
  Wire.begin(21, 22);
  
  u8g2.begin();
  u8g2.enableUTF8Print(); 

  updateOLED("Init Audio...", "", 0, true);
  
  if (!myDFPlayer.begin(mySoftwareSerial)) {
    updateOLED("Audio Error!", "", 0, true);
    delay(2000);
  } else {
    myDFPlayer.volume(25); 
  }

  updateOLED("Connecting WiFi...", "", 0, true);

  // ============= ডাইনামিক ওয়াই-ফাই লজিক =============
  WiFiManager wm;
  
  // যদি আগের ওয়াই-ফাই না পায়, তবে এই ফাংশনটি কল হবে
  wm.setAPCallback(configModeCallback); 
  
  // ESP32 কতক্ষণ ওয়াই-ফাই খোঁজার চেষ্টা করবে (যেমন: ১৫ সেকেন্ড)
  // ১৫ সেকেন্ড পর সে অটোমেটিক হটস্পট চালু করবে
  wm.setConnectTimeout(15); 
  
  // হটস্পটের নাম "Smart_Trainer" (পাসওয়ার্ড ছাড়া)
  // এটি অটোমেটিক কানেক্ট করার চেষ্টা করবে, না পারলে হটস্পট অন করবে
  bool res = wm.autoConnect("Smart_Trainer"); 

  if(!res) {
    updateOLED("Failed to Connect!", "Restarting...", 0, true);
    delay(3000);
    ESP.restart(); // কানেক্ট না হলে রিস্টার্ট নেবে
  }
  // ====================================================

  server.on("/", handleRoot);
  server.begin();
  
  // ওয়াই-ফাই ইনফো ছোট ইংরেজি ফন্টে অপারেটরের জন্য দেখানো
  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_ncenB08_tr); 
  u8g2.setCursor(0, 15);
  u8g2.print("WiFi Connected!");
  u8g2.setCursor(0, 35);
  u8g2.print("IP: ");
  u8g2.print(WiFi.localIP());
  u8g2.sendBuffer();
  delay(3000);
}

// ================= কুইজ লজিক =================
void generateAndAskQuestion() {
  int n1, n2, correctAnswer, opAudio;
  String opStr;
  int opType = random(1, 4); 

  if (opType == 1) { 
    n1 = random(1, 50); n2 = random(1, 50); correctAnswer = n1 + n2;
    opStr = "+"; opAudio = 101;
  } 
  else if (opType == 2) { 
    n1 = random(10, 99); n2 = random(1, n1); correctAnswer = n1 - n2;
    opStr = "-"; opAudio = 102;
  } 
  else { 
    n1 = random(2, 11); n2 = random(2, 10); correctAnswer = n1 * n2;
    opStr = "x"; opAudio = 103;
  }

  // প্রশ্নটিকে বাংলায় কনভার্ট করে স্ট্রিং বানানো
  String qText_BN = toBanglaNum(String(n1)) + " " + opStr + " " + toBanglaNum(String(n2)) + " = ?";

  // স্ক্রিনে প্রশ্ন দেখানো
  updateOLED(qText_BN, "");

  // অডিওতে প্রশ্ন পড়ে শোনাবে
  myDFPlayer.play(n1);       delay(1000); 
  myDFPlayer.play(opAudio);  delay(1000); 
  myDFPlayer.play(n2);       delay(1000); 
  myDFPlayer.play(105);      delay(1200);

  String userInput = "";
  
  // উত্তরের জন্য অপেক্ষা
  while (true) {
    server.handleClient(); 
    
    char key = keypad.getKey();
    if (key) {
      if (key == '#') { break; } 
      else if (key >= '0' && key <= '9') {
        userInput += key;
        updateOLED(qText_BN, userInput); // লাইভ টাইপিং দেখানো
      }
      else if (key == '*') { 
        userInput = "";
        updateOLED(qText_BN, userInput); // ক্লিয়ার করা
      }
    }
  }

  // উত্তর যাচাই
  if (userInput.toInt() == correctAnswer) {
    correctAnswers++;
    updateOLED(qText_BN, userInput, 1); // 1 = টিক চিহ্ন
    
    digitalWrite(GREEN_LED, HIGH);
    digitalWrite(BUZZER, HIGH); delay(150); digitalWrite(BUZZER, LOW); // ছোট বিপ
    
    myDFPlayer.play(106); 
    delay(2000);
    digitalWrite(GREEN_LED, LOW);
  } else {
    wrongAnswers++;
    updateOLED(qText_BN, userInput, 2); // 2 = ক্রস চিহ্ন
    
    digitalWrite(RED_LED, HIGH);
    digitalWrite(BUZZER, HIGH); delay(500); digitalWrite(BUZZER, LOW); // লম্বা বিপ
    
    myDFPlayer.play(107); 
    delay(2000);
    digitalWrite(RED_LED, LOW);
  }
  
  totalQuestions++;
  delay(2000);
}

// ================= মেইন লুপ =================
void loop() {
  server.handleClient(); 
  
  if (currentQIndex < 5 && !quizFinished) {
    generateAndAskQuestion();
    currentQIndex++;
    
    if(currentQIndex >= 5) {
      quizFinished = true;
      
      // কুইজ শেষের স্ক্রিন সম্পূর্ণ ইংরেজিতে এবং "উঃ" হাইড করা
      updateOLED("Quiz Finished!", "Check Dashboard", 0, true);
      
      myDFPlayer.play(108); // 108.wav
    }
  }
}
