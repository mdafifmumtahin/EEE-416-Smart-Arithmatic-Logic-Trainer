#include "Arduino.h"
#include "DFRobotDFPlayerMini.h"

// ESP32 এর Hardware Serial 2 ব্যবহার করছি
HardwareSerial mySoftwareSerial(2); 
DFRobotDFPlayerMini myDFPlayer;

void setup() {
  Serial.begin(115200);
  
  // RX2 = 16, TX2 = 17
  mySoftwareSerial.begin(9600, SERIAL_8N1, 16, 17); 
  
  Serial.println();
  Serial.println("DFPlayer Mini Initializing...");

  // DFPlayer কানেক্ট হওয়া পর্যন্ত ওয়েট করবে
  if (!myDFPlayer.begin(mySoftwareSerial)) { 
    Serial.println("Error: Connection check koro ba SD card check koro!");
    while(true);
  }
  
  Serial.println("DFPlayer Mini Online! 🎉");
  
  myDFPlayer.volume(50);  // ভলিউম সেট করা (০ থেকে ৩০ এর মধ্যে)
  myDFPlayer.play(101); // mp3 ফোল্ডারের 001.wav ফাইলটি প্লে করবে
}

void loop() {
  // অডিও একা একাই বাজবে, loop-এ কিচ্ছু লেখার দরকার নেই!
}
