/**********************************************************************
 *  বাংলা গণিত শেখার যন্ত্র  —  Bangla Math Trainer  v3.0
 *  ESP32 + SSD1306 0.96" OLED + 4x4 Keypad + DFPlayer Mini + WiFiManager
 *
 *  !! এই ফোল্ডারে দুইটা ফাইল লাগবে !!
 *     Bangla_Math_Trainer.ino   (এই ফাইল)
 *     bn_bitmaps.h              (বাংলা লেখার বিটম্যাপ)
 *
 *  বাংলা লেখা আর u8g2 ফন্ট দিয়ে আঁকা হয় না। u8g2-তে কোনো shaping engine
 *  নেই বলে ি ে ো কার উল্টো দিকে বসে আর যুক্তবর্ণ ভেঙে যায়। তাই সব বাংলা
 *  লেখা HarfBuzz দিয়ে আগেই রেন্ডার করে বিটম্যাপ বানিয়ে রাখা হয়েছে —
 *  যা স্ক্রিনে দেখায় তা অক্ষরে অক্ষরে সঠিক।
 *
 *  KEYPAD
 *    মেনুতে : 2 বা A উপরে, 8 বা B নিচে, # বা D ঠিক আছে, তারা বা C পিছনে
 *    প্রশ্নে : 0-9 সংখ্যা, তারা মুছে ফেলা, হ্যাশ জমা দেওয়া, D বাদ দেওয়া
 **********************************************************************/

#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <Keypad.h>
#include <Preferences.h>
#include "DFRobotDFPlayerMini.h"
#include <U8g2lib.h>
#include <WiFiManager.h>
#include "bn_bitmaps.h"

// ───────────────────────── HARDWARE ─────────────────────────
#define GREEN_LED   18
#define RED_LED     19
#define BUZZER      23
#define DF_RX_PIN   16      // ESP32 RX2  <- DFPlayer TX
#define DF_TX_PIN   17      // ESP32 TX2  -> DFPlayer RX (1k resistor here)
#define SEED_PIN    34

WebServer server(80);
HardwareSerial dfSerial(2);
DFRobotDFPlayerMini myDFPlayer;
Preferences prefs;
U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

const byte ROWS = 4, COLS = 4;
char keys[ROWS][COLS] = {
  {'1','2','3','A'}, {'4','5','6','B'}, {'7','8','9','C'}, {'*','0','#','D'}
};
byte rowPins[ROWS] = {13, 12, 14, 27};
byte colPins[COLS] = {26, 25, 33, 32};
Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

// ───────────────────────── AUDIO TRACK MAP ─────────────────────────
//  0001-0099 সংখ্যা, 0100 একশ  — এগুলো তোমার আগে থেকেই আছে
#define A_PLUS     101   // যোগ
#define A_MINUS    102   // বিয়োগ
#define A_TIMES    103   // গুণ
#define A_DIV      104   // ভাগ
#define A_EQUALS   105   // সমান কত?
#define A_RIGHT    106   // সঠিক হয়েছে
#define A_WRONG    107   // হয়নি
#define A_DONE     108   // শেষের মিউজিক
// ── নতুন যেগুলো রেকর্ড করতে হবে ──
#define A_EASY     109
#define A_MEDIUM   110
#define A_HARD     111
#define A_LEARN    112
#define A_TEST     113
#define A_MATH     114
#define A_LOGIC    115
#define A_AND      116
#define A_OR       117
#define A_NOT      118
#define A_XOR      119
#define A_XNOR     120
#define A_NAND     121
#define A_NOR      122
#define A_TIMEUP   123
#define A_WELCOME  124
#define A_GREAT    125
#define A_TRYAGAIN 126
#define A_ANSWERIS 127
#define A_ZERO     128   // শূন্য

bool dfOK = false;

// ───────────────────────── DATA MODEL ─────────────────────────
#define MAX_STUDENTS  5
#define HIST_LEN      12
#define QUIZ_LEN      5

enum { T_ADD = 0, T_SUB, T_MUL, T_DIV, T_LOGIC, T_COUNT };

struct Student {
  char     name[24];
  uint16_t tTot, tCor;
  uint16_t topTot[T_COUNT];
  uint16_t topCor[T_COUNT];
  uint8_t  histN;
  uint8_t  hist[HIST_LEN];
  uint8_t  bestPct;
};
Student students[MAX_STUDENTS];
int8_t curStudent = 0;

struct Live {
  bool     active  = false;
  int8_t   student = -1;
  uint8_t  mode = 0, phase = 0, diff = 0;
  String   q = "", typed = "";
  uint8_t  qIdx = 0, qTotal = 0, cor = 0, wrg = 0;
  int16_t  secLeft = -1;
  uint8_t  lastRes = 0;
} live;

/*  NOTE: Arduino IDE injects auto-generated prototypes at the very top of
    the sketch, so every struct used in a function signature must be
    declared before the first function definition. Keep these here.       */

// glyph indices into G_BIG / G_SML / G_TNY (see bn_bitmaps.h)
#define GI_PLUS 10
#define GI_MINUS 11
#define GI_MUL  12
#define GI_DIV  13
#define GI_EQ   14
#define GI_QM   15
#define GI_SL   16
#define GI_PC   17
#define GI_SP   18

#define GS_BIG 0
#define GS_SML 1
#define GS_TNY 2

// a short sequence of glyphs — how every runtime number is drawn
struct GRun {
  uint8_t n = 0;
  uint8_t idx[20];
};

struct Question {
  GRun    run;        // গণিত: বাংলা সংখ্যার প্রশ্ন
  String  ascii;      // লজিক: "1 AND 0 = ?"  (গণিতে ফাঁকা)
  String  web;        // ড্যাশবোর্ডে যা দেখাবে
  long    answer;
  uint8_t topic;
  int     aud1, audOp, aud2;   // aud1 < 0 মানে একক অপারেটর (NOT)
  bool    binary;
};

struct Remote {
  volatile bool start = false;
  int8_t  student = 0;
  uint8_t mode = 0, phase = 0, diff = 0;
} remote;

// ───────────────────────── SMALL UTILITIES ─────────────────────────
String toBanglaNum(const String &en) {          // ড্যাশবোর্ডের জন্য
  String bn = "";
  for (uint16_t i = 0; i < en.length(); i++) {
    switch (en[i]) {
      case '0': bn += "০"; break;  case '1': bn += "১"; break;
      case '2': bn += "২"; break;  case '3': bn += "৩"; break;
      case '4': bn += "৪"; break;  case '5': bn += "৫"; break;
      case '6': bn += "৬"; break;  case '7': bn += "৭"; break;
      case '8': bn += "৮"; break;  case '9': bn += "৯"; break;
      default : bn += en[i];
    }
  }
  return bn;
}

void serviceDelay(uint32_t ms) {
  uint32_t t0 = millis();
  while (millis() - t0 < ms) { server.handleClient(); delay(2); }
}
char getKeyLive() { server.handleClient(); return keypad.getKey(); }
void beep(uint16_t ms) { digitalWrite(BUZZER, HIGH); delay(ms); digitalWrite(BUZZER, LOW); }

// ───────────────────────── AUDIO ─────────────────────────
/*  আগের সমস্যা: প্রতিটা কথার জন্য একটা আন্দাজের delay() দেওয়া ছিল, তাই
    কথা শেষ হওয়ার আগেই পরের ধাপে চলে যেত। DFPlayer ট্র্যাক শেষ হলে
    সিরিয়ালে জানায় (DFPlayerPlayFinished) — এখন সেটার জন্যই অপেক্ষা করি।
    ফাইল না থাকলে সে error পাঠায়, তখন সাথে সাথেই এগিয়ে যাই।            */
void audioFlush() { if (dfOK) while (myDFPlayer.available()) myDFPlayer.readType(); }

void audioSay(int track, uint16_t maxMs = 5000, uint16_t gapMs = 140) {
  if (!dfOK) { serviceDelay(200); return; }
  audioFlush();
  myDFPlayer.play(track);
  uint32_t t0 = millis();
  while (millis() - t0 < maxMs) {
    server.handleClient();
    if (myDFPlayer.available()) {
      uint8_t type = myDFPlayer.readType();
      if (type == DFPlayerPlayFinished) break;
      if (type == DFPlayerError)        break;   // ফাইল নেই — অপেক্ষা করার মানে নেই
    }
    delay(3);
  }
  serviceDelay(gapMs);
}

void sayNumber(long n) {
  if (n == 0)                 audioSay(A_ZERO);
  else if (n > 0 && n < 100)  audioSay((int)n);
  else if (n == 100)          audioSay(100);
}

void initAudio() {
  dfSerial.begin(9600, SERIAL_8N1, DF_RX_PIN, DF_TX_PIN);
  delay(1200);                                   // মডিউলটা জাগার সময় দিই
  for (uint8_t a = 0; a < 4 && !dfOK; a++) {
    if (myDFPlayer.begin(dfSerial, true, true)) dfOK = true;
    else delay(600);
  }
  if (dfOK) {
    myDFPlayer.reset();      delay(900);
    myDFPlayer.outputDevice(DFPLAYER_DEVICE_SD); delay(150);
    myDFPlayer.volume(24);   delay(60);
    myDFPlayer.volume(24);                       // প্রথমটা প্রায়ই হারিয়ে যায়
  }
}

// ───────────────────── BITMAP TEXT ENGINE ─────────────────────
const BnImg *gset(uint8_t s) { return s == GS_BIG ? G_BIG : (s == GS_SML ? G_SML : G_TNY); }

void grClear(GRun &r) { r.n = 0; }
void grPush(GRun &r, uint8_t g) { if (r.n < 20) r.idx[r.n++] = g; }
void grNum(GRun &r, long v) {
  if (v < 0) { grPush(r, GI_MINUS); v = -v; }
  char buf[12]; ltoa(v, buf, 10);
  for (char *p = buf; *p; p++) grPush(r, *p - '0');
}
void grStr(GRun &r, const String &digits) {          // "০" নয়, "12" ধরনের ASCII
  for (uint16_t i = 0; i < digits.length(); i++)
    if (digits[i] >= '0' && digits[i] <= '9') grPush(r, digits[i] - '0');
}

int grWidth(const GRun &r, uint8_t set) {
  const BnImg *G = gset(set);
  int w = 0;
  for (uint8_t i = 0; i < r.n; i++) w += G[r.idx[i]].w + 1;
  return w > 0 ? w - 1 : 0;
}
void grDraw(const GRun &r, int x, int y, uint8_t set) {
  const BnImg *G = gset(set);
  for (uint8_t i = 0; i < r.n; i++) {
    const BnImg &g = G[r.idx[i]];
    if (g.data) u8g2.drawXBMP(x, y, g.w, g.h, g.data);
    x += g.w + 1;
  }
}
void grDrawCenter(const GRun &r, int y, uint8_t set) {
  grDraw(r, (128 - grWidth(r, set)) / 2, y, set);
}

void bnDraw(uint8_t id, int x, int y) {
  const BnImg &b = BN[id];
  u8g2.drawXBMP(x, y, b.w, b.h, b.data);
}
void bnDrawCenter(uint8_t id, int y) { bnDraw(id, (128 - BN[id].w) / 2, y); }

// একটা বাংলা লেবেল + তার পাশে সংখ্যা, একসাথে মাঝখানে বসানো
void bnValueCenter(uint8_t id, const GRun &r, int y, uint8_t set) {
  int total = BN[id].w + 5 + grWidth(r, set);
  int x = (128 - total) / 2;
  bnDraw(id, x, y);
  grDraw(r, x + BN[id].w + 5, y, set);
}

// ───────────────────────── SCREENS ─────────────────────────
void screenOne(uint8_t id) {
  u8g2.clearBuffer(); bnDrawCenter(id, 23); u8g2.sendBuffer();
}
void screenTwo(uint8_t id1, uint8_t id2) {
  u8g2.clearBuffer(); bnDrawCenter(id1, 12); bnDrawCenter(id2, 34); u8g2.sendBuffer();
}

void drawTick(int x, int y, bool ok) {
  if (ok) {
    u8g2.drawLine(x, y + 8, x + 4, y + 12);
    u8g2.drawLine(x + 1, y + 8, x + 5, y + 12);
    u8g2.drawLine(x + 4, y + 12, x + 11, y + 3);
    u8g2.drawLine(x + 5, y + 12, x + 12, y + 3);
  } else {
    u8g2.drawLine(x, y + 3, x + 10, y + 13);
    u8g2.drawLine(x + 1, y + 3, x + 11, y + 13);
    u8g2.drawLine(x + 10, y + 3, x, y + 13);
    u8g2.drawLine(x + 11, y + 3, x + 1, y + 13);
  }
}

/*  প্রশ্নের পর্দা
    0..5    টাইমার বার
    6..29   প্রশ্ন (বড় সংখ্যা)
    32..49  উঃ + যা টাইপ হয়েছে + ঠিক/ভুল চিহ্ন
    52..61  কত নম্বর প্রশ্ন                                            */
void screenQuestion(const Question &q, const String &typed, uint8_t res,
                    int16_t secLeft, int16_t secTotal, uint8_t qIdx, uint8_t qTotal) {
  u8g2.clearBuffer();

  if (secTotal > 0 && secLeft >= 0) {
    int w = map(secLeft, 0, secTotal, 0, 126);
    u8g2.drawFrame(0, 0, 128, 6);
    if (w > 0) u8g2.drawBox(1, 1, w, 4);
  }

  // ── প্রশ্ন ──
  if (q.binary) {
    u8g2.setFont(u8g2_font_10x20_tr);
    int w = u8g2.getStrWidth(q.ascii.c_str());
    u8g2.setCursor((128 - w) / 2, 27);
    u8g2.print(q.ascii);
  } else {
    grDrawCenter(q.run, 6, GS_BIG);
  }

  // ── উত্তরের লাইন ──
  int mark = res ? 16 : 0;
  if (q.binary) {
    u8g2.setFont(u8g2_font_10x20_tr);
    int wv = u8g2.getStrWidth(typed.c_str());
    int total = BN[BN_ANS].w + 6 + wv + mark;
    int x = (128 - total) / 2;
    bnDraw(BN_ANS, x, 32);
    u8g2.setCursor(x + BN[BN_ANS].w + 6, 48);
    u8g2.print(typed);
    if (res) drawTick(x + total - 13, 33, res == 1);
  } else {
    GRun r; grClear(r); grStr(r, typed);
    int total = BN[BN_ANS].w + 6 + grWidth(r, GS_SML) + mark;
    int x = (128 - total) / 2;
    bnDraw(BN_ANS, x, 32);
    grDraw(r, x + BN[BN_ANS].w + 6, 32, GS_SML);
    if (res) drawTick(x + total - 13, 33, res == 1);
  }

  // ── কত নম্বর প্রশ্ন ──
  GRun p; grClear(p); grNum(p, qIdx); grPush(p, GI_SL); grNum(p, qTotal);
  grDraw(p, 126 - grWidth(p, GS_TNY), 52, GS_TNY);

  u8g2.sendBuffer();
}

/*  স্ক্রলিং মেনু — পাতায় দুইটা করে অপশন, নিচে পাতার নম্বর
    0..17   শিরোনাম
    18..35  অপশন ১
    36..53  অপশন ২
    54..63  পাতা ২/৩                                                    */
int menuSelect(uint8_t titleId, const uint8_t *items, uint8_t n, uint8_t startIdx = 0) {
  int sel = startIdx < n ? startIdx : 0;
  const uint8_t PER = 2;
  uint8_t pages = (n + PER - 1) / PER;
  bool redraw = true;

  while (true) {
    if (redraw) {
      uint8_t top = (sel / PER) * PER;
      u8g2.clearBuffer();
      bnDrawCenter(titleId, 0);

      for (uint8_t i = 0; i < PER; i++) {
        uint8_t k = top + i;
        if (k >= n) break;
        int y = 18 + i * 18;
        const BnImg &b = BN[items[k]];
        int x = (128 - b.w) / 2;
        u8g2.drawXBMP(x, y, b.w, b.h, b.data);
        if (k == sel) u8g2.drawRFrame(x - 6, y, b.w + 12, 18, 4);
      }

      // পাতার নম্বর — ৬৪ পিক্সেলে "পাতা" শব্দটার জায়গা হয় না, তাই শুধু ২/৩
      GRun pg; grClear(pg);
      grNum(pg, sel / PER + 1); grPush(pg, GI_SL); grNum(pg, pages);
      grDrawCenter(pg, 54, GS_TNY);

      u8g2.sendBuffer();
      redraw = false;
    }

    if (remote.start) return -2;                  // ড্যাশবোর্ড থেকে শুরু হয়েছে

    char k = getKeyLive();
    if (!k) { delay(5); continue; }

    if      (k == '2' || k == 'A') { sel = (sel - 1 + n) % n; redraw = true; beep(15); }
    else if (k == '8' || k == 'B') { sel = (sel + 1) % n;     redraw = true; beep(15); }
    else if (k == '#' || k == 'D') { beep(40); return sel; }
    else if (k == '*' || k == 'C') { beep(40); return -1; }
  }
}

// ───────────────────────── PERSISTENCE ─────────────────────────
void resetStudent(uint8_t i, bool keepName = true) {
  if (!keepName) snprintf(students[i].name, sizeof(students[i].name), "শিশু %d", i + 1);
  students[i].tTot = students[i].tCor = 0;
  for (uint8_t t = 0; t < T_COUNT; t++) { students[i].topTot[t] = 0; students[i].topCor[t] = 0; }
  students[i].histN = 0;
  memset(students[i].hist, 0, sizeof(students[i].hist));
  students[i].bestPct = 0;
}
void saveAll() {
  prefs.begin("btrainer", false);
  prefs.putBytes("st", students, sizeof(students));
  prefs.end();
}
void loadAll() {
  prefs.begin("btrainer", true);
  bool ok = (prefs.getBytesLength("st") == sizeof(students));
  if (ok) prefs.getBytes("st", students, sizeof(students));
  prefs.end();
  if (!ok) { for (uint8_t i = 0; i < MAX_STUDENTS; i++) resetStudent(i, false); saveAll(); }
}
void pushSession(uint8_t i, uint8_t pct) {
  Student &s = students[i];
  if (s.histN < HIST_LEN) s.hist[s.histN++] = pct;
  else { for (uint8_t k = 1; k < HIST_LEN; k++) s.hist[k - 1] = s.hist[k]; s.hist[HIST_LEN - 1] = pct; }
  if (pct > s.bestPct) s.bestPct = pct;
  saveAll();
}

// ───────────────────────── QUESTIONS ─────────────────────────
void buildArithRun(Question &q, long a, long b, uint8_t opGlyph, const char *opWeb) {
  grClear(q.run);
  grNum(q.run, a);  grPush(q.run, GI_SP);
  grPush(q.run, opGlyph);
  grPush(q.run, GI_SP);  grNum(q.run, b);  grPush(q.run, GI_SP);
  grPush(q.run, GI_EQ);  grPush(q.run, GI_SP);  grPush(q.run, GI_QM);
  q.web = toBanglaNum(String(a)) + " " + opWeb + " " + toBanglaNum(String(b)) + " = ?";
}

/*  কঠিন নিয়ম: প্রতিটা সংখ্যা আর উত্তর অবশ্যই ০ থেকে ১০০ এর ভিতরে।
    অডিও ট্র্যাক আছে ০০০১–০১০০ পর্যন্ত, তাই এর বাইরে গেলে যন্ত্র পড়তেও
    পারবে না। নিচের জেনারেটরগুলো সীমা মেনেই বানায়, আর তার পরেও
    makeArith() শেষে একবার যাচাই করে — না মিললে আবার বানায়।           */
#define VAL_MAX 100

bool arithOnce(Question &q, uint8_t diff, uint8_t pick) {
  long a, b;
  q.binary = false; q.ascii = ""; q.aud1 = q.aud2 = q.audOp = -1;

  if (diff == 0) {                                   // সহজ: এক অঙ্ক, হাতে থাকে না
    if (pick == 0) {
      a = random(1, 9); b = random(1, 10 - a);       // a + b <= 9
      q.answer = a + b; q.topic = T_ADD;
      buildArithRun(q, a, b, GI_PLUS, "+"); q.audOp = A_PLUS;
    } else {
      a = random(2, 10); b = random(1, a);           // ধার নিতে হয় না
      q.answer = a - b; q.topic = T_SUB;
      buildArithRun(q, a, b, GI_MINUS, "-"); q.audOp = A_MINUS;
    }
  }
  else if (diff == 1) {                              // মাঝারি
    if (pick == 0) {                                 // দুই অঙ্কের যোগ, হাতে থাকে
      a = random(11, 89);
      long hi = VAL_MAX - a; if (hi < 11) return false;
      b = random(11, hi + 1);
      if ((a % 10) + (b % 10) < 10) return false;     // হাতে না থাকলে বাদ
      q.answer = a + b; q.topic = T_ADD;
      buildArithRun(q, a, b, GI_PLUS, "+"); q.audOp = A_PLUS;
    }
    else if (pick == 1) {                            // দুই অঙ্কের বিয়োগ, ধার লাগে
      a = random(21, 100); b = random(11, a);
      if ((a % 10) >= (b % 10)) return false;         // ধার না লাগলে বাদ
      q.answer = a - b; q.topic = T_SUB;
      buildArithRun(q, a, b, GI_MINUS, "-"); q.audOp = A_MINUS;
    }
    else {                                           // নামতা, গুণফল <= ১০০
      a = random(2, 11); b = random(2, 11);
      q.answer = a * b; q.topic = T_MUL;
      buildArithRun(q, a, b, GI_MUL, "×"); q.audOp = A_TIMES;
    }
  }
  else {                                             // কঠিন
    if (pick == 0) {                                 // বড় যোগ, তবু যোগফল <= ১০০
      a = random(31, 70);
      long hi = VAL_MAX - a; if (hi < 21) return false;
      b = random(21, hi + 1);
      if ((a % 10) + (b % 10) < 10) return false;
      q.answer = a + b; q.topic = T_ADD;
      buildArithRun(q, a, b, GI_PLUS, "+"); q.audOp = A_PLUS;
    }
    else if (pick == 1) {                            // বড় বিয়োগ, ধার সহ
      a = random(51, 100); b = random(12, a - 5);
      if ((a % 10) >= (b % 10)) return false;
      q.answer = a - b; q.topic = T_SUB;
      buildArithRun(q, a, b, GI_MINUS, "-"); q.audOp = A_MINUS;
    }
    else if (pick == 2) {                            // দুই অঙ্ক x এক অঙ্ক
      b = random(3, 10);
      long hi = VAL_MAX / b; if (hi < 11) return false;
      a = random(11, hi + 1);                        // গুণফল <= ১০০
      q.answer = a * b; q.topic = T_MUL;
      buildArithRun(q, a, b, GI_MUL, "×"); q.audOp = A_TIMES;
    }
    else {                                           // নিঃশেষে ভাগ
      b = random(2, 10);
      long hi = VAL_MAX / b;
      long r = random(2, hi + 1);                    // ভাজ্য = b * r <= ১০০
      a = b * r;
      if (a < 11) return false;
      q.answer = r; q.topic = T_DIV;
      buildArithRun(q, a, b, GI_DIV, "÷"); q.audOp = A_DIV;
    }
  }

  q.aud1 = (int)a; q.aud2 = (int)b;
  // শেষ পাহারা: সংখ্যা আর উত্তর তিনটাই যেন ০–১০০ এর ভিতরে থাকে
  if (a < 0 || a > VAL_MAX) return false;
  if (b < 0 || b > VAL_MAX) return false;
  if (q.answer < 0 || q.answer > VAL_MAX) return false;
  return true;
}

Question makeArith(uint8_t diff) {
  Question q;
  // কোন অপারেশন হবে তা একবারই ঠিক হয়, নইলে যে শর্তগুলো বেশি বাতিল হয়
  // (হাতে থাকা, ধার নেওয়া) সেই অপারেশনগুলোই কম আসত
  uint8_t nOps = (diff == 0) ? 2 : (diff == 1 ? 3 : 4);
  uint8_t pick = random(0, nOps);
  for (uint8_t tries = 0; tries < 60; tries++)
    if (arithOnce(q, diff, pick)) return q;

  // কখনোই এখানে আসার কথা নয়, তবু নিরাপদ একটা প্রশ্ন ফেরত দিই
  long a = random(1, 9), b = random(1, 10 - a);
  q.binary = false; q.ascii = ""; q.topic = T_ADD;
  q.answer = a + b; q.aud1 = (int)a; q.aud2 = (int)b; q.audOp = A_PLUS;
  buildArithRun(q, a, b, GI_PLUS, "+");
  return q;
}

enum { L_AND = 0, L_OR, L_NOT, L_NAND, L_NOR, L_XOR, L_XNOR };
const char *L_NAME[]  = {"AND", "OR", "NOT", "NAND", "NOR", "XOR", "XNOR"};
const int   L_AUDIO[] = {A_AND, A_OR, A_NOT, A_NAND, A_NOR, A_XOR, A_XNOR};

Question makeLogic(uint8_t diff) {
  Question q; q.binary = true; q.topic = T_LOGIC; grClear(q.run);
  uint8_t pool = (diff == 0) ? 2 : (diff == 1 ? 5 : 7);
  uint8_t op = random(0, pool);
  int a = random(0, 2), b = random(0, 2);

  switch (op) {
    case L_AND:  q.answer = a & b;    break;
    case L_OR:   q.answer = a | b;    break;
    case L_NOT:  q.answer = !a;       break;
    case L_NAND: q.answer = !(a & b); break;
    case L_NOR:  q.answer = !(a | b); break;
    case L_XOR:  q.answer = a ^ b;    break;
    case L_XNOR: q.answer = !(a ^ b); break;
  }
  q.audOp = L_AUDIO[op];

  if (op == L_NOT) {
    q.ascii = String("NOT ") + a + " = ?";
    q.aud1 = -1; q.aud2 = a;
  } else {
    q.ascii = String(a) + " " + L_NAME[op] + " " + b + " = ?";
    q.aud1 = a; q.aud2 = b;
  }
  q.web = q.ascii;
  return q;
}

void speakQuestion(const Question &q) {
  if (q.aud1 >= 0) sayNumber(q.aud1);
  audioSay(q.audOp);
  sayNumber(q.aud2);
  audioSay(A_EQUALS);
}

// ───────────────────────── ANSWER ENTRY ─────────────────────────
//  1 = সঠিক, 2 = ভুল, 3 = সময় শেষ, 9 = বাদ দেওয়া হয়েছে
uint8_t askAndGrade(const Question &q, int16_t limitSec, uint8_t qIdx, uint8_t qTotal) {
  String typed = "";
  live.q = q.web; live.typed = ""; live.qIdx = qIdx; live.qTotal = qTotal;
  live.lastRes = 0; live.secLeft = -1;

  // প্রশ্নটা আগে পুরোপুরি পড়ে শোনানো হয়, তারপর ঘড়ি চালু হয়
  screenQuestion(q, typed, 0, -1, -1, qIdx, qTotal);
  speakQuestion(q);

  uint32_t t0 = millis();
  int16_t lastShown = -99;

  while (true) {
    int16_t left = -1;
    if (limitSec > 0) {
      int32_t used = (millis() - t0) / 1000;
      left = limitSec - used;
      if (left <= 0) { live.secLeft = 0; return 3; }
    }
    live.secLeft = left;

    if (left != lastShown) {
      screenQuestion(q, typed, 0, left, limitSec, qIdx, qTotal);
      lastShown = left;
    }

    if (remote.start) return 9;

    char k = getKeyLive();
    if (!k) { delay(4); continue; }

    if (k == '#') {
      if (typed.length() == 0) { beep(250); continue; }     // খালি জমা নয়
      break;
    }
    else if (k == '*') { typed = ""; live.typed = ""; lastShown = -99; beep(15); }
    else if (k == 'D') { return 9; }
    else if (k >= '0' && k <= '9') {
      uint8_t maxLen = q.binary ? 1 : 5;
      if (typed.length() >= maxLen) typed = "";           // ভরে গেলে নতুন করে শুরু
      typed += k;
      live.typed = typed;
      lastShown = -99;
      beep(15);
    }
  }

  return (typed.toInt() == q.answer) ? 1 : 2;
}

void feedback(const Question &q, uint8_t res) {
  live.lastRes = res;
  screenQuestion(q, live.typed, res == 1 ? 1 : 2, -1, -1, live.qIdx, live.qTotal);
  if (res == 1) {
    digitalWrite(GREEN_LED, HIGH); beep(120);
    audioSay(A_RIGHT);
    digitalWrite(GREEN_LED, LOW);
  } else {
    digitalWrite(RED_LED, HIGH); beep(400);
    audioSay(res == 3 ? A_TIMEUP : A_WRONG);
    digitalWrite(RED_LED, LOW);
  }
}

void revealAnswer(const Question &q) {
  u8g2.clearBuffer();
  if (q.binary) {
    u8g2.setFont(u8g2_font_10x20_tr);
    int w = u8g2.getStrWidth(q.ascii.c_str());
    u8g2.setCursor((128 - w) / 2, 20);
    u8g2.print(q.ascii);
  } else {
    grDrawCenter(q.run, 2, GS_SML);
  }
  GRun r; grClear(r); grNum(r, q.answer);
  bnValueCenter(BN_ANSWER_IS, r, 32, GS_SML);
  u8g2.sendBuffer();

  audioSay(A_ANSWERIS);
  sayNumber(q.answer);
  serviceDelay(900);
}

// ───────────────────────── SESSIONS ─────────────────────────
int16_t timeLimitFor(uint8_t mode, uint8_t diff) {
  if (mode == 0) { if (diff == 0) return 0; return diff == 1 ? 25 : 18; }
  else           { if (diff == 0) return 0; return diff == 1 ? 15 : 10; }
}

void runLearning(uint8_t mode, uint8_t diff) {
  audioSay(A_LEARN);
  for (uint8_t i = 1; i <= QUIZ_LEN; i++) {
    Question q = (mode == 0) ? makeArith(diff) : makeLogic(diff);
    uint8_t res = askAndGrade(q, 0, i, QUIZ_LEN);
    if (res == 9) return;
    feedback(q, res);
    revealAnswer(q);                      // শেখার সময় উত্তর সবসময় দেখানো হয়
    serviceDelay(500);
  }
  screenTwo(BN_FINISH, BN_AGAIN);
  audioSay(A_DONE, 9000);
  serviceDelay(800);
}

void runTest(uint8_t mode, uint8_t diff) {
  audioSay(A_TEST);
  int16_t limit = timeLimitFor(mode, diff);
  uint8_t cor = 0;
  Student &s = students[curStudent];

  for (uint8_t i = 1; i <= QUIZ_LEN; i++) {
    Question q = (mode == 0) ? makeArith(diff) : makeLogic(diff);
    uint8_t res = askAndGrade(q, limit, i, QUIZ_LEN);
    if (res == 9) return;

    feedback(q, res);
    if (res != 1) revealAnswer(q);

    s.tTot++; s.topTot[q.topic]++;
    if (res == 1) { cor++; s.tCor++; s.topCor[q.topic]++; live.cor++; }
    else          { live.wrg++; }
    serviceDelay(400);
  }

  uint8_t pct = (cor * 100) / QUIZ_LEN;
  pushSession(curStudent, pct);

  GRun sc; grClear(sc); grNum(sc, cor); grPush(sc, GI_SL); grNum(sc, QUIZ_LEN);
  GRun pc; grClear(pc); grNum(pc, pct); grPush(pc, GI_PC);

  u8g2.clearBuffer();
  bnDrawCenter(BN_RESULT, 0);
  bnValueCenter(BN_CORRECT, sc, 22, GS_SML);
  grDrawCenter(pc, 44, GS_SML);
  u8g2.sendBuffer();

  audioSay(A_DONE, 9000);
  audioSay(pct >= 60 ? A_GREAT : A_TRYAGAIN);
  screenOne(pct >= 60 ? BN_GREAT : BN_TRYAGAIN);
  serviceDelay(1500);
}
// ───────────────────────── TEACHER DASHBOARD ─────────────────────────
static const char PAGE_HTML[] PROGMEM = R"HTML(<!DOCTYPE html><html lang="bn"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>গণিত যন্ত্র — শিক্ষকের পাতা</title><style>
:root{
  --slate:#123B33; --slate2:#0C2A24; --paper:#FDF6E3; --ink:#22302C;
  --mango:#F6A623; --melon:#E8505B; --sky:#2E86AB; --leaf:#6BBF59; --chalk:#EAF4EF;
}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--paper);color:var(--ink);
  font-family:'Hind Siliguri','Noto Sans Bengali','SolaimanLipi','Segoe UI',sans-serif;
  line-height:1.65;padding-bottom:56px}
.wrap{max-width:920px;margin:0 auto;padding:0 18px}

/* hero: a chalk slate showing what the child is doing right now */
.slate{background:var(--slate);color:var(--chalk);border-radius:0 0 34px 34px;
  padding:26px 18px 34px;box-shadow:inset 0 -6px 0 rgba(0,0,0,.25)}
.slate h1{font-size:1.35rem;font-weight:700;letter-spacing:.2px}
.slate h1 span{opacity:.6;font-weight:400;font-size:.95rem;display:block;margin-top:2px}
.now{margin-top:20px;border:3px dashed rgba(234,244,239,.35);border-radius:24px;
  padding:22px 18px;text-align:center}
.now .q{font-size:2.6rem;font-weight:700;letter-spacing:1px;min-height:1.2em}
.now .meta{opacity:.72;font-size:.95rem;margin-top:8px}
.now .typed{margin-top:10px;font-size:1.2rem}
.pill{display:inline-block;padding:3px 14px;border-radius:999px;font-size:.85rem;margin:0 4px}
.on{background:var(--leaf);color:#0C2A24}.off{background:rgba(234,244,239,.18)}
.clock{font-size:1.1rem;margin-top:10px;color:var(--mango)}

/* student chips */
.kids{display:flex;gap:10px;overflow-x:auto;padding:20px 0 6px}
.kid{flex:0 0 auto;background:#fff;border:2px solid #E4DAC0;border-radius:18px;
  padding:9px 16px;cursor:pointer;font-size:1rem;white-space:nowrap}
.kid.sel{background:var(--slate);color:var(--chalk);border-color:var(--slate)}
.kid.live::after{content:"●";color:var(--leaf);margin-right:6px;font-size:.8rem}

/* stat tiles */
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-top:8px}
.tile{background:#fff;border-radius:20px;padding:16px 18px;border-bottom:6px solid var(--mango)}
.tile b{display:block;font-size:2.1rem;line-height:1.1}
.tile small{opacity:.65;font-size:.9rem}
.t2{border-color:var(--leaf)}.t3{border-color:var(--melon)}.t4{border-color:var(--sky)}

.panel{background:#fff;border-radius:24px;padding:20px;margin-top:16px}
.panel h2{font-size:1.05rem;font-weight:700;margin-bottom:4px}
.panel p{font-size:.88rem;opacity:.62;margin-bottom:14px}
canvas{width:100%;height:auto;display:block}

.tools{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}
button{font-family:inherit;font-size:.95rem;border:none;border-radius:14px;
  padding:11px 20px;cursor:pointer;background:var(--slate);color:var(--chalk)}
button.ghost{background:transparent;color:var(--ink);border:2px solid #E4DAC0}
button:focus-visible{outline:3px solid var(--mango);outline-offset:2px}
.empty{opacity:.55;font-size:.95rem;padding:22px 0;text-align:center}

/* remote control: looks like a row of chalk switches, not a form */
.ctl{background:var(--slate);color:var(--chalk);border-radius:24px;padding:20px;margin-top:16px}
.ctl h2{font-size:1.05rem;margin-bottom:4px}
.ctl p{font-size:.88rem;opacity:.6;margin-bottom:16px}
.row{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px}
.row>span{width:82px;opacity:.7;font-size:.9rem}
.sw{border:2px solid rgba(234,244,239,.3);background:none;color:var(--chalk);
  border-radius:999px;padding:7px 18px;font-size:.95rem}
.sw.on{background:var(--mango);border-color:var(--mango);color:#0C2A24}
.go{background:var(--leaf);color:#0C2A24;font-size:1.05rem;padding:13px 28px;width:100%;margin-top:6px}
.go:disabled{opacity:.45;cursor:not-allowed}
@media(prefers-reduced-motion:no-preference){.kid{transition:background .15s}}
</style></head><body>

<div class="slate"><div class="wrap">
  <h1>গণিত শেখার যন্ত্র<span>শিক্ষকের পাতা</span></h1>
  <div class="now">
    <div class="q" id="q">—</div>
    <div class="typed" id="typed"></div>
    <div class="clock" id="clock"></div>
    <div class="meta" id="meta">যন্ত্রটি এখন বিশ্রামে আছে</div>
  </div>
</div></div>

<div class="wrap">
  <div class="kids" id="kids"></div>

  <div class="tiles">
    <div class="tile"><small>মোট প্রশ্ন</small><b id="k1">0</b></div>
    <div class="tile t2"><small>সঠিক</small><b id="k2">0</b></div>
    <div class="tile t3"><small>ভুল</small><b id="k3">0</b></div>
    <div class="tile t4"><small>নির্ভুলতা</small><b id="k4">0%</b></div>
  </div>

  <div class="panel">
    <h2>কোন বিষয়ে কেমন পারছে</h2>
    <p>প্রতিটি বিষয়ে সঠিক উত্তরের হার</p>
    <canvas id="bars" width="880" height="300"></canvas>
    <div class="empty" id="barsEmpty" hidden>এখনো কোনো পরীক্ষা হয়নি</div>
  </div>

  <div class="panel">
    <h2>উন্নতির ধারা</h2>
    <p>শেষ ১২টি পরীক্ষার ফলাফল, ক্রম অনুসারে</p>
    <canvas id="line" width="880" height="300"></canvas>
    <div class="empty" id="lineEmpty" hidden>অন্তত দুটি পরীক্ষা শেষ হলে ধারা দেখা যাবে</div>
  </div>

  <div class="ctl">
    <h2>যন্ত্র চালান এখান থেকে</h2>
    <p>বেছে নিয়ে শুরু দিলে যন্ত্রের মেনু পেরিয়ে সরাসরি ওই সেশন চালু হবে</p>
    <div class="row"><span>শিশু</span><div id="cStudent"></div></div>
    <div class="row"><span>বিষয়</span><div id="cMode"></div></div>
    <div class="row"><span>ধাপ</span><div id="cPhase"></div></div>
    <div class="row"><span>কঠিনতা</span><div id="cDiff"></div></div>
    <button class="go" id="go" onclick="go()">যন্ত্রে শুরু করুন</button>
  </div>

  <div class="tools">
    <button onclick="rename()">নাম বদলান</button>
    <button class="ghost" onclick="wipe()">এই শিশুর হিসাব মুছুন</button>
  </div>
</div>

<script>
const TOPICS=['যোগ','বিয়োগ','গুণ','ভাগ','লজিক'];
const COLORS=['#F6A623','#E8505B','#2E86AB','#6BBF59','#9B6BBF'];
let D=null, sel=0;

function css(v){return getComputedStyle(document.documentElement).getPropertyValue(v).trim()}
function fit(c){const r=window.devicePixelRatio||1,w=c.clientWidth;
  c.width=w*r;c.height=300*r;const x=c.getContext('2d');x.setTransform(r,0,0,r,0,0);
  x.clearRect(0,0,w,300);return[x,w,300]}

function bars(s){
  const [x,W,H]=fit(document.getElementById('bars'));
  const any=s.topTot.some(v=>v>0);
  document.getElementById('barsEmpty').hidden=any;
  document.getElementById('bars').hidden=!any;
  if(!any)return;
  const pad=34,base=H-46,n=TOPICS.length,gap=W/n;
  x.strokeStyle='#E4DAC0';x.lineWidth=1;
  for(let g=0;g<=4;g++){const y=pad+(base-pad)*g/4;
    x.beginPath();x.moveTo(0,y);x.lineTo(W,y);x.stroke();}
  x.font='500 14px "Hind Siliguri",sans-serif';x.textAlign='center';
  for(let i=0;i<n;i++){
    const t=s.topTot[i],c=s.topCor[i],p=t?Math.round(c*100/t):0;
    const bw=Math.min(60,gap*.5),cx=gap*i+gap/2,h=(base-pad)*p/100;
    x.fillStyle=t?COLORS[i]:'#E9E1CC';
    x.beginPath();x.roundRect(cx-bw/2,base-h,bw,Math.max(h,3),[10,10,0,0]);x.fill();
    x.fillStyle=css('--ink');
    if(t){x.fillText(p+'%',cx,base-h-9);}
    x.globalAlpha=t?1:.45;
    x.fillText(TOPICS[i],cx,base+22);
    x.globalAlpha=.5;x.font='400 12px "Hind Siliguri",sans-serif';
    x.fillText(t?(c+'/'+t):'—',cx,base+40);
    x.globalAlpha=1;x.font='500 14px "Hind Siliguri",sans-serif';
  }
}

function line(s){
  const h=s.hist||[];
  const [x,W,H]=fit(document.getElementById('line'));
  document.getElementById('lineEmpty').hidden=h.length>=2;
  document.getElementById('line').hidden=h.length<2;
  if(h.length<2)return;
  const L=40,R=12,T=26,B=44,w=W-L-R,ht=H-T-B;
  x.strokeStyle='#E4DAC0';x.lineWidth=1;
  x.font='400 12px "Hind Siliguri",sans-serif';x.fillStyle='#8A8577';x.textAlign='right';
  for(let g=0;g<=4;g++){const v=100-g*25,y=T+ht*g/4;
    x.beginPath();x.moveTo(L,y);x.lineTo(W-R,y);x.stroke();x.fillText(v,L-8,y+4);}
  const px=i=>L+w*i/(h.length-1), py=v=>T+ht*(1-v/100);
  x.beginPath();x.moveTo(px(0),py(h[0]));
  for(let i=1;i<h.length;i++)x.lineTo(px(i),py(h[i]));
  x.strokeStyle=css('--slate');x.lineWidth=3;x.lineJoin='round';x.stroke();
  x.lineTo(px(h.length-1),T+ht);x.lineTo(L,T+ht);x.closePath();
  x.fillStyle='rgba(18,59,51,.08)';x.fill();
  x.textAlign='center';
  for(let i=0;i<h.length;i++){
    x.beginPath();x.arc(px(i),py(h[i]),5,0,7);
    x.fillStyle=h[i]>=60?css('--leaf'):css('--melon');x.fill();
    x.fillStyle='#8A8577';x.fillText(i+1,px(i),H-14);
  }
}

function draw(){
  if(!D)return;
  const s=D.students[sel];
  document.getElementById('kids').innerHTML=D.students.map((v,i)=>
    `<div class="kid ${i==sel?'sel':''} ${D.live.student==i&&D.live.active?'live':''}" onclick="pick(${i})">${v.name}</div>`).join('');
  document.getElementById('k1').textContent=s.tTot;
  document.getElementById('k2').textContent=s.tCor;
  document.getElementById('k3').textContent=s.tTot-s.tCor;
  document.getElementById('k4').textContent=(s.tTot?Math.round(s.tCor*100/s.tTot):0)+'%';

  const l=D.live;
  document.getElementById('q').textContent=l.active?l.q:'—';
  document.getElementById('typed').textContent=l.active&&l.typed?('উত্তর: '+l.typed):'';
  document.getElementById('clock').textContent=(l.active&&l.secLeft>=0)?('বাকি সময় '+l.secLeft+' সেকেন্ড'):'';
  document.getElementById('meta').innerHTML=l.active
    ? `<span class="pill on">${D.students[l.student].name}</span>
       <span class="pill off">${l.mode}</span><span class="pill off">${l.phase}</span>
       <span class="pill off">${l.diff}</span><span class="pill off">প্রশ্ন ${l.qIdx}/${l.qTotal}</span>`
    : 'যন্ত্রটি এখন বিশ্রামে আছে';

  bars(s);line(s);drawCtl();
}
function pick(i){sel=i;draw()}

const MODES=['গণিত','লজিক'],PHASES=['শিখি','যাচাই'],DIFFS=['সহজ','মাঝারি','কঠিন'];
let R={student:0,mode:0,phase:0,diff:0};
function sw(hostId,list,key){
  document.getElementById(hostId).innerHTML=list.map((t,i)=>
    `<button class="sw ${R[key]==i?'on':''}" onclick="setR('${key}',${i})">${t}</button>`).join(' ');
}
function drawCtl(){
  sw('cStudent',D.students.map(v=>v.name),'student');
  sw('cMode',MODES,'mode');sw('cPhase',PHASES,'phase');sw('cDiff',DIFFS,'diff');
  const b=document.getElementById('go');
  b.disabled=D.live.active;
  b.textContent=D.live.active?'এখন একটি সেশন চলছে':'যন্ত্রে শুরু করুন';
}
function setR(k,v){R[k]=v;drawCtl();
  fetch(`/api/set?student=${R.student}&mode=${R.mode}&phase=${R.phase}&diff=${R.diff}`);}
function go(){
  fetch(`/api/set?student=${R.student}&mode=${R.mode}&phase=${R.phase}&diff=${R.diff}&start=1`);
  const b=document.getElementById('go');b.disabled=true;b.textContent='যন্ত্রে পাঠানো হলো';
}
let first=true;
async function tick(){try{
  D=await(await fetch('/api/data')).json();
  if(first&&D.remote){R={student:D.remote.student,mode:D.remote.mode,
    phase:D.remote.phase,diff:D.remote.diff};sel=R.student;first=false;}
  draw()}catch(e){}}
async function rename(){
  const v=prompt('নতুন নাম লিখুন',D.students[sel].name);
  if(v&&v.trim()){await fetch('/api/name?i='+sel+'&n='+encodeURIComponent(v.trim()));tick()}
}
async function wipe(){
  if(confirm(D.students[sel].name+' — এর সব হিসাব মুছে যাবে। চালিয়ে যাবেন?')){
    await fetch('/api/reset?i='+sel);tick()}
}
tick();setInterval(tick,1500);
window.addEventListener('resize',draw);
</script></body></html>)HTML";

const char *MODE_BN[]  = {"গণিত", "লজিক"};
const char *PHASE_BN[] = {"শিখি", "যাচাই"};
const char *DIFF_BN[]  = {"সহজ", "মাঝারি", "কঠিন"};

void handleRoot() { server.send_P(200, "text/html; charset=utf-8", PAGE_HTML); }

String jsonEscape(const char *s) {
  String o = "";
  for (const char *p = s; *p; p++) {
    if (*p == '"' || *p == '\\') { o += '\\'; o += *p; }
    else if ((uint8_t)*p < 0x20) continue;
    else o += *p;
  }
  return o;
}

void handleData() {
  String j = "{\"students\":[";
  for (uint8_t i = 0; i < MAX_STUDENTS; i++) {
    Student &s = students[i];
    if (i) j += ",";
    j += "{\"name\":\"";  j += jsonEscape(s.name);
    j += "\",\"tTot\":";  j += s.tTot;
    j += ",\"tCor\":";     j += s.tCor;
    j += ",\"best\":";     j += s.bestPct;
    j += ",\"topTot\":[";
    for (uint8_t t = 0; t < T_COUNT; t++) { if (t) j += ","; j += s.topTot[t]; }
    j += "],\"topCor\":[";
    for (uint8_t t = 0; t < T_COUNT; t++) { if (t) j += ","; j += s.topCor[t]; }
    j += "],\"hist\":[";
    for (uint8_t h = 0; h < s.histN; h++) { if (h) j += ","; j += s.hist[h]; }
    j += "]}";
  }
  j += "],\"live\":{\"active\":";  j += (live.active ? "true" : "false");
  j += ",\"student\":";             j += (int)live.student;
  j += ",\"mode\":\"";             j += MODE_BN[live.mode];
  j += "\",\"phase\":\"";         j += PHASE_BN[live.phase];
  j += "\",\"diff\":\"";          j += DIFF_BN[live.diff];
  j += "\",\"q\":\"";             j += live.q;
  j += "\",\"typed\":\"";         j += live.typed;
  j += "\",\"qIdx\":";             j += live.qIdx;
  j += ",\"qTotal\":";              j += live.qTotal;
  j += ",\"secLeft\":";             j += (int)live.secLeft;
  j += "},\"remote\":{\"student\":"; j += (int)remote.student;
  j += ",\"mode\":";  j += remote.mode;
  j += ",\"phase\":"; j += remote.phase;
  j += ",\"diff\":";  j += remote.diff;
  j += ",\"armed\":"; j += (remote.start ? "true" : "false");
  j += "}}";
  server.send(200, "application/json; charset=utf-8", j);
}

void handleName() {
  int i = server.arg("i").toInt();
  String n = server.arg("n");
  if (i >= 0 && i < MAX_STUDENTS && n.length()) {
    strncpy(students[i].name, n.c_str(), sizeof(students[i].name) - 1);
    students[i].name[sizeof(students[i].name) - 1] = 0;
    saveAll();
  }
  server.send(200, "text/plain", "ok");
}

void handleReset() {
  int i = server.arg("i").toInt();
  if (i >= 0 && i < MAX_STUDENTS) { resetStudent(i, true); saveAll(); }
  server.send(200, "text/plain", "ok");
}

void handleSet() {
  if (server.hasArg("student")) {
    int v = server.arg("student").toInt();
    if (v >= 0 && v < MAX_STUDENTS) remote.student = v;
  }
  if (server.hasArg("mode"))  remote.mode  = constrain(server.arg("mode").toInt(),  0, 1);
  if (server.hasArg("phase")) remote.phase = constrain(server.arg("phase").toInt(), 0, 1);
  if (server.hasArg("diff"))  remote.diff  = constrain(server.arg("diff").toInt(),  0, 2);
  if (server.arg("start") == "1") remote.start = true;
  server.send(200, "text/plain", "ok");
}

void configModeCallback(WiFiManager *wm) { screenOne(BN_WIFI_AP); }

// ───────────────────────── SETUP ─────────────────────────
void setup() {
  Serial.begin(115200);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  randomSeed(analogRead(SEED_PIN) ^ micros());

  Wire.begin(21, 22);
  u8g2.begin();

  screenTwo(BN_TITLE, BN_BOOTING);
  delay(400);

  initAudio();
  screenOne(dfOK ? BN_AUDIO_OK : BN_AUDIO_BAD);
  delay(800);

  loadAll();

  screenOne(BN_WIFI_SEARCH);
  WiFiManager wm;
  wm.setAPCallback(configModeCallback);
  wm.setConnectTimeout(15);
  wm.setConfigPortalTimeout(180);
  if (!wm.autoConnect("Smart_Trainer")) {
    screenOne(BN_WIFI_FAIL);
    delay(2500);
    ESP.restart();
  }

  server.on("/",          handleRoot);
  server.on("/api/data",  handleData);
  server.on("/api/name",  handleName);
  server.on("/api/reset", handleReset);
  server.on("/api/set",   handleSet);
  server.begin();

  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_7x14B_tr);
  u8g2.setCursor(0, 20); u8g2.print("Dashboard at");
  u8g2.setCursor(0, 42); u8g2.print(WiFi.localIP());
  u8g2.sendBuffer();

  audioSay(A_WELCOME, 6000);
  serviceDelay(1200);
}

// ───────────────────────── MAIN FLOW ─────────────────────────
void showAddress() {
  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_7x14B_tr);
  u8g2.setCursor(0, 18); u8g2.print("Open in browser:");
  u8g2.setCursor(0, 40); u8g2.print(WiFi.localIP());
  u8g2.setFont(u8g2_font_4x6_tr);
  u8g2.setCursor(0, 62); u8g2.print("press any key");
  u8g2.sendBuffer();
  while (!getKeyLive()) delay(5);
}

void runSession(uint8_t mode, uint8_t phase, uint8_t diff) {
  live.active = true; live.student = curStudent;
  live.mode = mode;   live.phase = phase;  live.diff = diff;
  live.cor = live.wrg = 0; live.qIdx = 0; live.qTotal = QUIZ_LEN;

  screenTwo(BN_START, mode == 0 ? BN_MATH : BN_LOGIC);
  serviceDelay(900);

  if (phase == 0) runLearning(mode, diff);
  else            runTest(mode, diff);

  live.active = false; live.secLeft = -1; live.q = ""; live.typed = "";
  serviceDelay(500);
}

const uint8_t KID_IDS[]   = {BN_KID1, BN_KID2, BN_KID3, BN_KID4, BN_KID5, BN_ADDRESS};
const uint8_t MODE_IDS[]  = {BN_MATH, BN_LOGIC};
const uint8_t PHASE_IDS[] = {BN_LEARN, BN_TEST};
const uint8_t DIFF_IDS[]  = {BN_EASY, BN_MEDIUM, BN_HARD};

void loop() {
  server.handleClient();
  live.active = false; live.q = ""; live.typed = ""; live.secLeft = -1;

  if (remote.start) {                       // শিক্ষক ড্যাশবোর্ড থেকে শুরু করেছেন
    remote.start = false;
    curStudent = remote.student;
    beep(60);
    runSession(remote.mode, remote.phase, remote.diff);
    return;
  }

  int pick = menuSelect(BN_WHO_PLAYS, KID_IDS, MAX_STUDENTS + 1, curStudent);
  if (pick < 0) return;
  if (pick == MAX_STUDENTS) { showAddress(); return; }
  curStudent = pick;

  int mode = menuSelect(BN_PICK_TOPIC, MODE_IDS, 2, 0);
  if (mode < 0) return;
  audioSay(mode == 0 ? A_MATH : A_LOGIC);

  int phase = menuSelect(BN_WHAT_DO, PHASE_IDS, 2, 0);
  if (phase < 0) return;

  int diff = menuSelect(BN_HOW_HARD, DIFF_IDS, 3, 0);
  if (diff < 0) return;
  audioSay(diff == 0 ? A_EASY : (diff == 1 ? A_MEDIUM : A_HARD));

  runSession(mode, phase, diff);
}
