#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <Keypad.h>

// Wi-Fi Credentials
const char* ssid = "MMA";
const char* password = "4sdRF6$Rt4";

WebServer server(80);
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Keypad Setup
const byte ROWS = 4; 
const byte COLS = 4; 
char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};
byte rowPins[ROWS] = {13, 12, 14, 27}; 
byte colPins[COLS] = {26, 25, 33, 32}; 
Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

// Quiz Variables
int totalQuestionsAsked = 0;
int correctAnswers = 0;
int wrongAnswers = 0;
int currentQIndex = 0;
bool quizFinished = false;

// 5 Questions Array
String questions[5] = {"2 + 1 = ?", "5 - 2 = ?", "4 * 2 = ?", "9 / 3 = ?", "7 + 5 = ?"};
int answers[5] = {3, 3, 8, 3, 12};

// Custom Characters (Tick and Cross)
uint8_t tickMark[8] = {0x00, 0x01, 0x03, 0x16, 0x1C, 0x08, 0x00, 0x00};
uint8_t crossMark[8] = {0x00, 0x11, 0x0A, 0x04, 0x0A, 0x11, 0x00, 0x00};

// Web Server HTML Handler
void handleRoot() {
  String html = "<!DOCTYPE html><html lang='bn'><head>";
  html += "<meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'>";
  html += "<meta http-equiv='refresh' content='2'> "; // 2 seconds auto-refresh
  html += "<title>Q-Labs Teacher Dashboard</title>";
  html += "<style>";
  html += "body { background-color: #E0F7FA; font-family: 'Comic Sans MS', sans-serif; text-align: center; color: #333; margin: 0; padding: 20px; }";
  html += "h1 { color: #00796B; font-size: 32px; text-shadow: 2px 2px #B2DFDB; }";
  html += ".container { display: flex; flex-wrap: wrap; justify-content: center; gap: 20px; margin-top: 30px; }";
  html += ".card { background: white; border-radius: 25px; padding: 25px; width: 220px; box-shadow: 0 10px 20px rgba(0,0,0,0.1); border: 4px dashed #ccc; }";
  html += ".card h2 { font-size: 50px; margin: 10px 0; }";
  html += ".card p { font-size: 22px; font-weight: bold; margin: 0; }";
  html += ".total { border-color: #FFC107; color: #FF9800; background-color: #FFFDE7; }";
  html += ".correct { border-color: #4CAF50; color: #388E3C; background-color: #E8F5E9; }";
  html += ".wrong { border-color: #FF5252; color: #D32F2F; background-color: #FFEBEE; }";
  html += "</style></head><body>";

  html += "<h1>🌟 EEE 416 Smart Trainer Dashboard 🌟</h1>";
  html += "<p>লাইভ স্টুডেন্ট পারফরম্যান্স মনিটরিং</p>";
  html += "<div class='container'>";
  
  html += "<div class='card total'><p>মোট প্রশ্ন 📝</p><h2>" + String(totalQuestionsAsked) + "</h2></div>";
  html += "<div class='card correct'><p>সঠিক উত্তর ✔️</p><h2>" + String(correctAnswers) + "</h2></div>";
  html += "<div class='card wrong'><p>ভুল উত্তর ❌</p><h2>" + String(wrongAnswers) + "</h2></div>";
  
  html += "</div><br><br><div>👶 Designed for fun learning! 👶</div>";
  html += "</body></html>";

  server.send(200, "text/html", html);
}

void setup() {
  Serial.begin(115200);
  
  // Initialize LCD & Custom Chars
  Wire.begin(21, 22);
  lcd.init();
  lcd.backlight();
  lcd.createChar(0, tickMark);
  lcd.createChar(1, crossMark);

  lcd.setCursor(0, 0);
  lcd.print("Connecting WiFi.");

  // Wi-Fi Setup
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.print(".");
  }
  
  lcd.clear();
  lcd.print("WiFi Connected!");
  lcd.setCursor(0, 1);
  lcd.print(WiFi.localIP());
  
  server.on("/", handleRoot);
  server.begin();
  
  delay(3000); // Show IP for 3 seconds
}

void askQuestion(int index) {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(questions[index]);
  lcd.setCursor(0, 1);
  lcd.print("Ans: ");

  String userInput = "";
  
  // Wait for user input loop
  while (true) {
    server.handleClient(); // KEEP SERVER ALIVE DURING WAIT!
    
    char key = keypad.getKey();
    if (key) {
      if (key == '#') { 
        break; // Enter Button Pressed
      } 
      else if (key >= '0' && key <= '9') {
        userInput += key;
        lcd.print(key); // Show typed number on LCD
      }
      else if (key == '*') { 
        // Clear input if wrong button pressed
        userInput = "";
        lcd.setCursor(5, 1);
        lcd.print("          "); 
        lcd.setCursor(5, 1);
      }
    }
  }

  // Check Answer
  if (userInput.toInt() == answers[index]) {
    correctAnswers++;
    lcd.setCursor(14, 1);
    lcd.write(0); // Print Custom Tick Mark
  } else {
    wrongAnswers++;
    lcd.setCursor(14, 1);
    lcd.write(1); // Print Custom Cross Mark
  }
  
  totalQuestionsAsked++;
  delay(2500); // Wait to show the tick/cross before next question
}

void loop() {
  server.handleClient(); // Always handle web requests
  
  if (currentQIndex < 5 && !quizFinished) {
    askQuestion(currentQIndex);
    currentQIndex++;
    
    if(currentQIndex >= 5) {
      quizFinished = true;
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Quiz Finished!");
      lcd.setCursor(0, 1);
      lcd.print("Check Dashboard");
    }
  }
}
